HOW TO USE
----------

Just drag & drop .zip or .img file containing firmware to edit field. If firmware is using encrypted squashfs enter decrypting key in Key field (example of key used in few PlayOn!HD releases: 12345678195454322338264935438139)

Firmware will be automatically extracted:

Install files into \install folder.
Yaffs2 (if available) into current folder.
Squashfs (if available) into \squash folder.
usr.local.etc into \usr.local.etc folder.



KNOWN BUGS
----------

It's not possible to decrypt squashfs in directory with spaces (bug in pfcd) - use directories without any spaces instead.



COPYRIGHT
---------

7-zip was created by Igor Pavlov (http://www.7-zip.org/)

pfcd was created by	Lossless (http://playonhd.ucoz.ru/)

RFUT was created by mikka (http://playon.unixstorm.org/)

Original unsquashfs was created by Phillip Lougher (http://sourceforge.net/projects/squashfs/). Windows port created by Nikolay Pelov (ftp://ftp.slax.org/useful-binaries/win32/squashfs-tools/)

unyaffs was created by Kai.Wei.cn (http://code.google.com/p/unyaffs/)