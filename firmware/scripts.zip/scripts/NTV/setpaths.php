<?php
	$SCIEZKA = dirname($_SERVER["SCRIPT_FILENAME"]) . '/';
	
	$ntv_conf = fopen("/usr/local/etc/ntv.conf", 'w');
	fwrite($ntv_conf, $SCIEZKA);
	fclose($ntv_conf);
	
	echo "NTV path has been set to: <b>" . $SCIEZKA . "</b>";
?>