#!/bin/sh
# Version 3.0,
# Copyright (c) 2012 kmarty, killerman
# This file is a part of xLiveCZ, this project doesnt have
# any support from Xtreamer company and just be design for 
# realtek based players

CUR_DIR=$(dirname $0)
msdl=$CUR_DIR/msdl

TYPE=`echo "$QUERY_STRING" | sed -n -e 's/^.*type=\([^&]*\).*$/\1/p' -e "s/%20/ /g"`
URL=`echo "$QUERY_STRING" | sed -n -e 's/^.*url=\([^&]*\).*$/\1/p' -e "s/%20/ /g"`
C=`echo "$QUERY_STRING" | sed -n -e 's/^.*c=\([^&]*\).*$/\1/p' -e "s/%20/ /g"`
N=`echo "$QUERY_STRING" | sed -n -e 's/^.*n=\([^&]*\).*$/\1/p' -e "s/%20/ /g"`
P=`echo "$QUERY_STRING" | sed -n -e 's/^.*p=\([^&]*\).*$/\1/p' -e "s/%20/ /g"`
S=`echo "$QUERY_STRING" | sed -n -e 's/^.*s=\([^&]*\).*$/\1/p' -e "s/%20/ /g"`
T=`echo "$QUERY_STRING" | sed -n -e 's/^.*t=\([^&]*\).*$/\1/p' -e "s/%20/ /g"`
W=`echo "$QUERY_STRING" | sed -n -e 's/^.*w=\([^&]*\).*$/\1/p' -e "s/%20/ /g"`
Y=`echo "$QUERY_STRING" | sed -n -e 's/^.*y=\([^&]*\).*$/\1/p' -e "s/%20/ /g"`
L=`echo "$QUERY_STRING" | sed -n -e 's/^.*l=\([^&]*\).*$/\1/p' -e "s/%20/ /g"`
F=`echo "$QUERY_STRING" | sed -n -e 's/^.*f=\([^&]*\).*$/\1/p' -e "s/%20/ /g"`
A=`echo "$QUERY_STRING" | sed -n -e 's/^.*a=\([^&]*\).*$/\1/p' -e "s/%20/ /g"`
ACT=`echo "$QUERY_STRING" | sed -n -e "s/^.*act='\(.*\)'.*$/\1/p" -e "s/%20/ /g"`
TIP=`echo "$QUERY_STRING" | sed -n -e 's/^.*tip=\([^&]*\).*$/\1/p' -e "s/%20/ /g"`

if [ "$TYPE" == "test" ]; then
   echo -e "Content-type: video/wmv\n"
   exec $msdl -q -o - "$URL"
fi

if [ "$TYPE" == "live" ]; then
   echo -e "Content-type: video/wmv\n"
   exec $msdl -q --useragent "VLC/2.0" "$URL" -o -
fi

if [ "$TYPE" == "mixtv" ]; then
   echo -e "Content-type: video/wmv\n"
   exec $msdl -q --useragent "VLC/2.0" "$URL" --username "vsadmin" --password "yxcvbnm123!" -o -
fi

if [ "$TYPE" == "mix" ]; then
   echo -e "Content-type: video/wmv\n"
   exec $msdl -q --useragent "VLC/2.0" "$URL" --username "vsadmin" --password "Uhbijn123!!!" -o -
fi

if [ "$TYPE" == "ruske" ]; then
   echo -e "Content-type: video/wmv\n"
   exec $msdl "$URL" -o -
fi