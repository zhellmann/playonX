<?php
// ###############################################################
// ##                                                           ##
// ##   http://sites.google.com/site/pavelbaco/                 ##
// ##   Copyright (C) 2012  Pavel Ba�o   (killerman)            ##
// ##                                                           ##
// ## This file is a part of xLiveCZ, this project doesnt have  ##
// ## any support from Xtreamer company and just be design for  ##  
// ## realtek based players									    ##
// ###############################################################
echo "<?xml version='1.0' encoding='UTF8' ?>";
$DIR_SCRIPT_ROOT  = current(explode('xLiveCZ/', dirname(__FILE__).'/')).'xLiveCZ/';
$HTTP_SCRIPT_ROOT = current(explode('scripts/', 'http://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']).'/')).'scripts/';
?>
<!--Realtek chip players - killerman - without any support Xtreamer-->
<rss version="2.0" xmlns:media="http://purl.org/dc/elements/1.1/" xmlns:dc="http://purl.org/dc/elements/1.1/">
<mediaDisplay name=photoView
	rowCount=3
	columnCount=5
	drawItemText="no"
	showHeader="no" 
	menuBorderColor="0:0:0"
	sideColorBottom="0:0:0"
	sideColorTop="0:0:0"
	itemImageXPC="10"
	itemOffsetXPC="7"
	backgroundColor="0:0:0"
	sliding="no"
	idleImageXPC="45"
	idleImageYPC="45"
	idleImageWidthPC="8.6"
	idleImageHeightPC="6"
	itemGapYPC="2"
	itemGapXPC="1.5"
	>
		<idleImage><?php echo $DIR_SCRIPT_ROOT; ?>image/busy0.png</idleImage>
		<idleImage><?php echo $DIR_SCRIPT_ROOT; ?>image/busy1.png</idleImage>
		<idleImage><?php echo $DIR_SCRIPT_ROOT; ?>image/busy2.png</idleImage>
		<idleImage><?php echo $DIR_SCRIPT_ROOT; ?>image/busy3.png</idleImage>
		<idleImage><?php echo $DIR_SCRIPT_ROOT; ?>image/busy4.png</idleImage>
		<idleImage><?php echo $DIR_SCRIPT_ROOT; ?>image/busy5.png</idleImage>
		<idleImage><?php echo $DIR_SCRIPT_ROOT; ?>image/busy6.png</idleImage>
		<idleImage><?php echo $DIR_SCRIPT_ROOT; ?>image/busy7.png</idleImage>
		<idleImage><?php echo $DIR_SCRIPT_ROOT; ?>image/busy8.png</idleImage>
		<idleImage><?php echo $DIR_SCRIPT_ROOT; ?>image/busy9.png</idleImage>
		<image redraw="no" offsetXPC="0" offsetYPC="0" widthPC="100" heightPC="18"><?php echo $DIR_SCRIPT_ROOT; ?>backgrounds/top.png</image>
		<text align="center" offsetXPC="0" offsetYPC="-2" widthPC="100" heightPC="20" fontSize="30" backgroundColor=-1:-1:-1 foregroundColor=250:250:250>
Beeg (18+)</text>

	</mediaDisplay>

<channel>


<item>
<title>Beeg latest</title>
<link>/adult/beeglatest.php</link>
<media:thumbnail url="http://cdn.nudevector.com/t/422/274/0.jpg "/>
<itemid>0</itemid>
</item>

<item>
<title>Beeg longest</title>
<link>/adult/beeglongest.php</link>
<media:thumbnail url="http://cdn.nudevector.com/t/148/835/0.jpg "/>
<itemid>1</itemid>
</item>

<item>
<title>Beeg milf</title>
<link>/adult/beegmilf.php</link>
<media:thumbnail url="http://cdn.nudevector.com/t/147/721/2.jpg" />
<itemid>2</itemid>
</item>

<item>
<title>Beeg teen</title>
<link>/adult/beegteen.php</link>
<media:thumbnail url="http://cdn.nudevector.com/t/147/721/9.jpg "/>
<itemid>3</itemid>
</item>

<item>
<title>Beeg college</title>
<link>/adult/beegcollege.php</link>
<media:thumbnail url="http://cdn.nudevector.com/t/328/321/4.jpg" />
<itemid>4</itemid>
</item>

<item>
<title>Beeg office</title>
<link>/adult/beegoffice.php</link>
<media:thumbnail url="http://cdn.nudevector.com/t/147/722/1.jpg" />
<itemid>5</itemid>
</item>

<item>
<title>Beeg party</title>
<link>/adult/beegparty.php</link>
<media:thumbnail url="http://cdn.nudevector.com/t/147/722/0.jpg "/>
<itemid>6</itemid>
</item>


<item>
<title>Beeg lesbian</title>
<link>/adult/beeglesbien.php</link>
<media:thumbnail url="http://cdn.nudevector.com/t/147/722/7.jpg" />
<itemid>7</itemid>
</item>

<item>
<title>Beeg student</title>
<link>/adult/beegstudent.php</link>
<media:thumbnail url="http://cdn.nudevector.com/t/147/722/9.jpg" />
<itemid>8</itemid>
</item>

<item>
<title>Beeg girlfriends</title>
<link>/adult/beeggirlfriends.php</link>
<media:thumbnail url="http://cdn.nudevector.com/t/148/044/9.jpg "/>
<itemid>9</itemid>
</item>

<item>
<title>Beeg moms</title>
<link>/adult/beegmoms.php</link>
<media:thumbnail url="http://cdn.nudevector.com/t/148/042/7.jpg "/>
<itemid>10</itemid>
</item>

</channel>
</rss>