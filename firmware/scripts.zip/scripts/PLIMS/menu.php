<?php
	$version = "2.6";
	$dirpath = dirname($_SERVER["SCRIPT_FILENAME"]) . '/';
	$webpath = 'http://' . $_SERVER['SERVER_ADDR'] . ':' . $_SERVER['SERVER_PORT'] . dirname($_SERVER['PHP_SELF']) . '/';
	$imgpath = $dirpath . 'image/';
	echo "<?xml version='1.0' encoding='UTF8' ?>\n";
?>
<rss version="2.0" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:media="http://purl.org/dc/elements/1.1/">

<mediaDisplay name="photoView" rowCount="3" columnCount="5" showHeader="no" drawItemText="no" showDefaultInfo="no" itemOffsetXPC="5" itemOffsetYPC="48" sliding="yes" itemHeightPC="12" itemWidthPC="17" itemBorderColor="0:0:0" itemBackgroundColor="0:0:0" idleImageXPC="92" idleImageYPC="93" idleImageWidthPC="5" idleImageHeightPC="5" backgroundColor="0:0:0" sideColorBottom="0:0:0" sideColorTop="-1:-1:-1" bottomYPC="90">

<idleImage><?php echo $imgpath; ?>loader_1.png</idleImage>
<idleImage><?php echo $imgpath; ?>loader_2.png</idleImage>
<idleImage><?php echo $imgpath; ?>loader_3.png</idleImage>
<idleImage><?php echo $imgpath; ?>loader_4.png</idleImage>
<idleImage><?php echo $imgpath; ?>loader_5.png</idleImage>
<idleImage><?php echo $imgpath; ?>loader_6.png</idleImage>
<idleImage><?php echo $imgpath; ?>loader_7.png</idleImage>
<idleImage><?php echo $imgpath; ?>loader_8.png</idleImage>

<text redraw="yes" backgroundColor="0:0:0" foregroundColor="255:255:255" offsetXPC="12" offsetYPC="89.5" widthPC="20" heightPC="5" fontSize="16">
<script>
	getItemInfo(-1, "title");
</script>
</text>

<text redraw="no" backgroundColor="-1:-1:-1" foregroundColor="255:255:255" offsetXPC="33" offsetYPC="90" widthPC="62" heightPC="4" fontSize="11">
<script>
	"PLIMS <?php echo $version; ?> by mikka, gfx by Pavlik, mos by Xury &#32; | &#32; http://playon.unixstorm.org";
</script>
</text>

<itemDisplay> 
<image offsetXPC="0" offsetYPC="0" widthPC="100" heightPC="100">
<script>
	if (getDrawingItemState() == "focus")
	{
		print("<?php echo $imgpath; ?>" + getItemInfo(-1, "media") + ".jpg");
	}
	else
	{
		print("<?php echo $imgpath; ?>" + getItemInfo(-1, "media") + "_off.jpg");
	}
</script>
</image>
</itemDisplay> 

<onUserInput>
<script>
	userInput = currentUserInput();
	if (userInput == "one" || userInput == "1" || userInput == "option_red")
	{
		showIdle();
		url="<?php echo $webpath; ?>scripts/xLiveCZ/category/tv/showlogin.php";
		jumpToLink("GotoPage");
		"true";
		redrawDisplay();
	}
	"false";
</script>
</onUserInput>


<backgroundDisplay>
<image offsetXPC="0" offsetYPC="0" widthPC="100" heightPC="100"><?php echo $imgpath; ?>background.jpg</image>
</backgroundDisplay>

</mediaDisplay>

<GotoPage>
	<link>
		<script>
			url;
		</script>
	</link>
</GotoPage>

<channel>

<item>
<title>WeebTV (1 - login)</title>
<link><?php echo $webpath; ?>scripts/xLiveCZ/category/tv/WeebTV.php?disk=<?php echo $webpath; ?>scripts/</link>
<media>logo-weebtv</media>
</item>

<item>
<title>Program TV</title>
<link><?php echo $webpath; ?>program.php</link>
<media>logo-txt</media>
</item>

<item>
<title>Muzyczne TV</title>
<link><?php echo $webpath; ?>scripts/xLiveCZ/category/rss/musictv.php</link>
<media>logo-muzycznetv</media>
</item>

<item>
<title>ipla</title>
<link><?php echo $webpath; ?>php/index.php</link>
<media>logo-ipla</media>
</item>

<item>
<title>iPtak</title>
<link><?php echo $webpath; ?>iptak.php</link>
<media>logo-iptak</media>
</item>

<item>
<title>PolskaStacja</title>
<link><?php echo $webpath; ?>polskastacja.php</link>
<media>logo-polskastacja</media>
</item>

<item>
<title>VOD TVP</title>
<link><?php echo $webpath; ?>tvp.php</link>
<media>logo-tvp</media>
</item>

<item>
<title>Bajki</title>
<link><?php echo $webpath; ?>scripts/xLiveCZ/category/rss/detske.php</link>
<media>logo-dladzieci</media>
</item>

<item>
<title>Polskie Radio</title>
<link><?php echo $webpath; ?>polskieradio.php</link>
<media>logo-polskieradio</media>
</item>

<item>
<title>tvn player</title>
<link><?php echo $webpath; ?>tvn.php</link>
<media>logo-tvn</media>
</item>

<item>
<title>HD Trailers</title>
<link><?php echo $webpath; ?>hdtrailers.php</link>
<media>logo-hdtrailers</media>
</item>

<item>
<title>OpenFM</title>
<link><?php echo $webpath; ?>openfm.php</link>
<media>logo-openfm</media>
</item>

<item>
<title>OnetVOD</title>
<link><?php echo $webpath; ?>onet.php</link>
<media>logo-onetvod</media>
</item>

<item>
<title>Game Trailers</title>
<link><?php echo $webpath; ?>gt.php</link>
<media>logo-gt</media>
</item>

<item>
<title>YouTube</title>
<link><?php echo $webpath; ?>scripts/xLiveCZ/category/yt.php</link>
<media>logo-yt</media>
</item>

<item>
<title>NBA + NASA</title>
<link><?php echo $webpath; ?>scripts/xLiveCZ/category/rss/nasa.php</link>
<media>nasanba</media>
</item>

<item>
<title>Polskie TV</title>
<link><?php echo $webpath; ?>scripts/xLiveCZ/category/rss/polskietv.php</link>
<media>polskie</media>
</item>

<item>
<title>Radio Eska i Zet</title>
<link><?php echo $webpath; ?>eskazet.php</link>
<media>logo-radiapl</media>
</item>

<item>
<title>PoplerTV</title>
<link><?php echo $webpath; ?>popler.php</link>
<media>logo-popler</media>
</item>

<item>
<title>Andrzej Mleczko</title>
<link><?php echo $webpath; ?>mleczko.php</link>
<media>logo-mleczko</media>
</item>

<item>
<title>Beeg (18+)</title>
<link><?php echo $webpath; ?>scripts/xLiveCZ/category/rss/beeg.php</link>
<media>logo-beeg</media>
</item>

</channel>
</rss>