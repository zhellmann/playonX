﻿<?php

//error_reporting(0);
define("dirpath", dirname($_SERVER["SCRIPT_FILENAME"]) . '/');
define("webpath", 'http://' . $_SERVER['SERVER_ADDR'] . ':' . $_SERVER['SERVER_PORT'] . dirname($_SERVER['PHP_SELF']) . '/');
define("imgpath", dirpath . 'image/');

define("LIVE", 'http://www.popler.tv/api/live_list.php');
define("VOD", 'http://www.popler.tv/api/vod.php');
chmod(dirpath . "bin/rtmpdump", 0755);

function geturl($url)	{
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)");
        $html = curl_exec($ch);
        curl_close($ch);
        return $html;
}

function generateIndexHeader()	{
echo <<<HEA
<?xml version='1.0' ?><rss version="2.0" encoding="UTF-8" xmlns:dc="http://purl.org/dc/elements/1.1/">

<mediaDisplay name="photoView" showHeader="no" rowCount="1" columnCount="4" drawItemText="no" showDefaultInfo="no" itemOffsetXPC="8" itemOffsetYPC="82" sliding="yes" itemBorderColor="0:128:255" itemHeightPC="10" itemWidthPC="20" itemBackgroundColor="0:0:0" idleImageXPC="92" idleImageYPC="93" idleImageWidthPC="5" idleImageHeightPC="5" backgroundColor="0:0:0" bottomYPC="100" sideTopHeightPC="0" mainPartColor="-1:-1:-1" sideColorBottom="-1:-1:-1" sideColorTop="-1:-1:-1">
HEA;

echo '
<idleImage>' . imgpath . 'loader_1.png</idleImage>
<idleImage>' . imgpath . 'loader_2.png</idleImage>
<idleImage>' . imgpath . 'loader_3.png</idleImage>
<idleImage>' . imgpath . 'loader_4.png</idleImage>
<idleImage>' . imgpath . 'loader_5.png</idleImage>
<idleImage>' . imgpath . 'loader_6.png</idleImage>
<idleImage>' . imgpath . 'loader_7.png</idleImage>
<idleImage>' . imgpath . 'loader_8.png</idleImage>

<itemDisplay>
<text align="center" redraw="no" offsetXPC="4" offsetYPC="1" widthPC="92" heightPC="100" fontSize="14" lines="1">
<script>
	getItemInfo(-1, "title");
</script>
</text>
</itemDisplay>

<backgroundDisplay>
<image redraw="no" offsetXPC="0" offsetYPC="0" widthPC="100" heightPC="100">/home/scripts/PLIMS/image/popler1.jpg</image>
</backgroundDisplay>
</mediaDisplay>		
				
<channel>

<item>
<title>Na żywo</title>
<link>' . webpath . 'popler.php?select=live</link>
</item>

<item>
<title>Najnowsze</title>
<link>' . webpath . 'popler.php?select=nowe</link>
</item>

<item>
<title>Najpopularniejsze</title>
<link>' . webpath . 'popler.php?select=popularne</link>
</item>

<item>
<title>Polecane</title>
<link>' . webpath . 'popler.php?select=polecane</link>
</item>
';
}

function getChannels($selection)	{
	foreach(glob(dirpath . 'tmp/popler*') as $tempfile)	{
		unlink($tempfile);
	}
	
	echo <<<SER
<?xml version='1.0' ?><rss version="2.0" encoding="UTF-8" xmlns:dc="http://purl.org/dc/elements/1.1/">

<mediaDisplay name="photoView" rowCount="2" columnCount="5" drawItemText="no" showDefaultInfo="yes" showHeader="no" itemOffsetXPC="2" itemOffsetYPC="58" sliding="yes" itemBorderColor="255:255:255" itemHeightPC="14" itemWidthPC="18" itemBackgroundColor="0:0:0" idleImageXPC="92" idleImageYPC="93" idleImageWidthPC="5" idleImageHeightPC="5" backgroundColor="0:0:0" sideColorBottom="0:0:0" sideColorTop="-1:-1:-1" bottomYPC="90">
SER;

	echo '
<idleImage>' . imgpath . 'loader_1.png</idleImage>
<idleImage>' . imgpath . 'loader_2.png</idleImage>
<idleImage>' . imgpath . 'loader_3.png</idleImage>
<idleImage>' . imgpath . 'loader_4.png</idleImage>
<idleImage>' . imgpath . 'loader_5.png</idleImage>
<idleImage>' . imgpath . 'loader_6.png</idleImage>
<idleImage>' . imgpath . 'loader_7.png</idleImage>
<idleImage>' . imgpath . 'loader_8.png</idleImage>

<itemDisplay>
<image redraw="no" offsetXPC="5" offsetYPC="5" widthPC="90" heightPC="90">
<script>
	getItemInfo(-1, "media");
</script>
</image>
</itemDisplay>

<backgroundDisplay>
<image redraw="no" offsetXPC="0" offsetYPC="0" widthPC="100" heightPC="100">' . imgpath . 'popler2.jpg</image>

</backgroundDisplay>

</mediaDisplay>

<channel>
';

	switch ($selection)	{
    case "live":
        $linki = LIVE;
        break;
    case "nowe":
        $linki = VOD . "?func=nowe";
        break;
    case "popularne":
        $linki = VOD . "?func=popularne";
        break;
    case "polecane":
        $linki = VOD . "?func=polecane";
        break;
	}

	$lista_kanalow = geturl($linki);
	$kanaly = json_decode($lista_kanalow, true);
	$nr=0;
	
	foreach ($kanaly as $kanal => $wartosc) {
		$plik = dirpath . "tmp/popler" . $nr . ".cgi";
		$weblik = webpath . "tmp/popler" . $nr . ".cgi";
		$play = fopen($plik, 'w');
		fwrite($play, "#!/bin/sh\ncat <<EOF\nContent-type: video/mp4\n\nEOF\nexec " . dirpath . "bin/rtmpdump -o - -v -b 60000 -r " . $wartosc["rtmp"]);
		fclose($play);
		chmod($plik, 0755);
		$nr++;
		
		if (empty($wartosc["name"]))	{
			$title = str_replace('http://www.popler.tv/', '', $wartosc["link"]);
		}
		else	{
			$title = $wartosc["name"];
		}
		
		echo '
<item>
<title>' . $title . '</title>
<link>'. $weblik . '</link>
<enclosure type="video/mp4" url="' . $weblik . '"/>
<media>' . $wartosc["thumb_mini"] . '</media>
</item>
';
	}
}

function generateFooter()	{
echo <<<FOO
</channel>
</rss>
FOO;
}

if (isset($_GET['select']))	{
	getChannels($_GET['select']);
	generateFooter();
}
else	{
	generateIndexHeader();
	generateFooter();
}
?>