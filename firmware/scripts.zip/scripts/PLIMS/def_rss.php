<?php
// define RSS item
$nav_rss['PLIMS'] = array (
	'module'=> 'PLIMS',
	'rss'	=> getMosUrl().'modules/PLIMS/menu.php',
	'icon'  => 'plims.png',
	'title' => 'PLIMS'
);

?>
