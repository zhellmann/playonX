<?php

define("dirpath", dirname($_SERVER["SCRIPT_FILENAME"]) . '/');
define("webpath", 'http://' . $_SERVER['SERVER_ADDR'] . ':' . $_SERVER['SERVER_PORT'] . dirname($_SERVER['PHP_SELF']) . '/');
define("imgpath", dirpath . 'image/');

$normalizeChars = array(
            '&Aacute;'=>'A', '&Agrave;'=>'A', '&Acirc;'=>'A', '&Atilde;'=>'A', '&Aring;'=>'A', '&Auml;'=>'A', '&AElig;'=>'AE', '&Ccedil;'=>'C',
            '&Eacute;'=>'E', '&Egrave;'=>'E', '&Ecirc;'=>'E', '&Euml;'=>'E', '&Iacute;'=>'I', '&Igrave;'=>'I', '&Icirc;'=>'I', '&Iuml;'=>'I', '&ETH;'=>'Eth',
            '&Ntilde;'=>'N', '&Oacute;'=>'O', '&Ograve;'=>'O', '&Ocirc;'=>'O', '&Otilde;'=>'O', '&Ouml;'=>'O', '&Oslash;'=>'O',
            '&Uacute;'=>'U', '&Ugrave;'=>'U', '&Ucirc;'=>'U', '&Uuml;'=>'U', '&Yacute;'=>'Y',
   
            '&aacute;'=>'a', '&agrave;'=>'a', '&acirc;'=>'a', '&atilde;'=>'a', '&aring;'=>'a', '&auml;'=>'a', '&aelig;'=>'ae', '&ccedil;'=>'c',
            '&eacute;'=>'e', '&egrave;'=>'e', '&ecirc;'=>'e', '&euml;'=>'e', '&iacute;'=>'i', '&igrave;'=>'i', '&icirc;'=>'i', '&iuml;'=>'i', '&eth;'=>'eth',
            '&ntilde;'=>'n', '&oacute;'=>'ó', '&ograve;'=>'o', '&ocirc;'=>'o', '&otilde;'=>'o', '&ouml;'=>'o', '&oslash;'=>'o',
            '&uacute;'=>'u', '&ugrave;'=>'u', '&ucirc;'=>'u', '&uuml;'=>'u', '&yacute;'=>'y',
           
            '&szlig;'=>'sz', '&thorn;'=>'thorn', '&yuml;'=>'y'
        );

function generateIndexHeader()	{
	$items = '';
	$handle = file_get_contents('http://playon.unixstorm.org/PLIMS/iptak.list');
	$cat_all= explode("\n", $handle);
	
 	if (($handle == FALSE) || (empty($cat_all)))
		$items = "<item>\n<name>No categories</name>\n</item>\n\n";
	else	{
		for ($i=0; $i<count($cat_all); $i++) 	{
			$cat= explode("|", $cat_all[$i]);
			
			if (!empty($cat[0]))
				$items .= "<item>\n<title>" . $cat[0] . "</title>\n<link>" . webpath . "iptak.php?cat=" . $cat[1] . "&amp;page=" . $cat[2] . "</link>\n<media>" . imgpath . $cat[1] . ".jpg</media>\n</item>\n\n";
		}
	}

echo <<<HEA
<?xml version='1.0' ?><rss version="2.0" encoding="UTF-8" xmlns:dc="http://purl.org/dc/elements/1.1/">

<mediaDisplay name="photoView" showHeader="no" rowCount="7" columnCount="3" columnPerPage="3" drawItemText="no" showDefaultInfo="no" itemOffsetXPC="2" itemOffsetYPC="2" sliding="yes" itemBorderColor="255:190:120" itemHeightPC="12" itemWidthPC="30" itemBackgroundColor="0:0:0" idleImageXPC="92" idleImageYPC="93" idleImageWidthPC="5" idleImageHeightPC="5" backgroundColor="0:0:0" bottomYPC="100" sideTopHeightPC="0" mainPartColor="-1:-1:-1" sideColorBottom="-1:-1:-1" sideColorTop="-1:-1:-1">
HEA;

echo '
<idleImage>' . imgpath . 'loader_1.png</idleImage>
<idleImage>' . imgpath . 'loader_2.png</idleImage>
<idleImage>' . imgpath . 'loader_3.png</idleImage>
<idleImage>' . imgpath . 'loader_4.png</idleImage>
<idleImage>' . imgpath . 'loader_5.png</idleImage>
<idleImage>' . imgpath . 'loader_6.png</idleImage>
<idleImage>' . imgpath . 'loader_7.png</idleImage>
<idleImage>' . imgpath . 'loader_8.png</idleImage>

<itemDisplay>
<image redraw="no" offsetXPC="2" offsetYPC="5" widthPC="30" heightPC="90">
<script>
	getItemInfo(-1, "media");
</script>
</image>

<text offsetXPC="36" offsetYPC="5" widthPC="63" heightPC="90" fontSize="15">
<script>
	getItemInfo(-1, "title");
</script>
</text>
</itemDisplay>
</mediaDisplay>		
				
<channel>
'
. 
$items
;
}

function generateSeriesHeader($cat, $page)	{
	$items = '';
	$handle = file_get_contents("http://playon.unixstorm.org/PLIMS/" . $cat . "/" . $page . ".list");
	$mov_all= explode("\n", $handle);
	
 	if (($handle == FALSE) || (empty($mov_all)))
		$items = "<item>\n<name>No movies</name>\n</item>\n\n";
	else	{
		for ($i=0; $i<count($mov_all); $i++) 	{
			$cat= explode("|", $mov_all[$i]);
			
			if (!empty($cat[0]))
				$items .= "<item>\n<title>" . $cat[0] . "</title>\n<onClick>\nshowIdle();\n" . 'url="' . webpath . 'scripts/xLiveCZ/modules/links/yt_iptak.php?file=https://www.youtube.com/watch?v=' . $cat[1] . '";' . "\nmovie=getUrl(url);\ncancelIdle();\nplayItemUrl(movie,10);\n</onClick>\n<media>" . $cat[2] . "</media>\n</item>\n\n";
		}
	}

echo <<<SER
<?xml version='1.0' ?><rss version="2.0" encoding="UTF-8" xmlns:dc="http://purl.org/dc/elements/1.1/">

<mediaDisplay name="photoView" showHeader="no" rowCount="3" columnCount="5" columnPerPage="5" drawItemText="no" showDefaultInfo="no" itemOffsetXPC="2" itemOffsetYPC="2" sliding="yes" itemBorderColor="0:0:0" itemHeightPC="28" itemWidthPC="17.2" itemBackgroundColor="0:0:0" idleImageXPC="92" idleImageYPC="93" idleImageWidthPC="5" idleImageHeightPC="5" backgroundColor="0:0:0"  sideTopHeightPC="0" mainPartColor="-1:-1:-1" sideColorBottom="-1:-1:-1" sideColorTop="-1:-1:-1">
SER;

echo '
<idleImage>' . imgpath . 'loader_1.png</idleImage>
<idleImage>' . imgpath . 'loader_2.png</idleImage>
<idleImage>' . imgpath . 'loader_3.png</idleImage>
<idleImage>' . imgpath . 'loader_4.png</idleImage>
<idleImage>' . imgpath . 'loader_5.png</idleImage>
<idleImage>' . imgpath . 'loader_6.png</idleImage>
<idleImage>' . imgpath . 'loader_7.png</idleImage>
<idleImage>' . imgpath . 'loader_8.png</idleImage>

<itemDisplay>
<image redraw="no" offsetXPC="5" offsetYPC="5" widthPC="90" heightPC="90">
<script>
	getItemInfo(-1, "media");
</script>
</image>

<image redraw="no" offsetXPC="0" offsetYPC="0" widthPC="100" heightPC="100" >
<script>
	if (getDrawingItemState() == "focus")
		"' . imgpath . 'focus.png";
	else
		"' . imgpath . 'nofocus.png";
</script>
</image>
</itemDisplay>

<text redraw="yes" fontSize="16" align="center" offsetXPC="2" offsetYPC="90" widthPC="88" heightPC="9" backgroundColor="0:0:0" foregroundColor="255:190:120">
<script>
  getItemInfo(-1, "title");
</script>
</text>
</mediaDisplay>

<channel>
'
. 
$items
;
}

function generateFooter()	{
echo <<<FOO
</channel>
</rss>
FOO;
}

if (isset($_GET['cat']) && isset($_GET['page'])) {
	generateSeriesHeader($_GET['cat'],$_GET['page']);
	generateFooter();
}
else	{
	generateIndexHeader();
	generateFooter();
}

?>