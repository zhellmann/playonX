<?php

/*
# Google Maps
# Made by: mikka [mika.hellmann@gmail.com]
#          Snappy46 [levesque.marcel@gmail.com]
# Version: 3.1
*/

$place=$_GET['find'];
$rpath = "http://127.0.0.1:" . $_SERVER['SERVER_PORT'] . dirname($_SERVER['SCRIPT_NAME']);
$lpath = dirname($_SERVER['SCRIPT_FILENAME']) . "/image/title.jpg";

echo <<<END
<?xml version="1.0"?>
<rss version="2.0" xmlns:media="http://purl.org/dc/elements/1.1/" xmlns:dc="http://purl.org/dc/elements/1.1/">

<onEnter>
  fov 	= 90;
  head 	= 180;
  pit	= 0;
  zoom 	= 11;
  mode	= "roadmap";
  
  loadXMLFile("http://maps.googleapis.com/maps/api/geocode/xml?address=$place&amp;sensor=false");
  unitLat=getXMLText("GeocodeResponse","result","geometry","location","lat");
  unitLng=getXMLText("GeocodeResponse","result","geometry","location","lng");
</onEnter>

<mediaDisplay name="onePartView" drawItemText="no" slidingItemText="no" showHeader="no" showDefaultInfo="no" sliding="no" idleImageWidthPC="0" idleImageHeightPC="0" sideLeftWidthPC="0" sideRightWidthPC="0" backgroundColor="0:0:0">
		
<backgroundDisplay>
	<script>
	redrawDisplay();
	
	if (mode == "roadmap" || mode == "satellite" || mode == "terrain" || mode == "hybrid") {
		gLink = "http://maps.googleapis.com/maps/api/staticmap?center=" + unitLat +"," + unitLng + "&amp;size=600x400&amp;sensor=false&amp;zoom=" + zoom + "&amp;maptype=" + mode ; 
	}

	else  {
  	      gLink = "http://maps.googleapis.com/maps/api/streetview?location=" + unitLat +"," + unitLng + "&amp;size=600x400&amp;sensor=false&amp;fov=" + fov + "&amp;heading=" + head + "&amp;pitch=" + pit;
	}
	</script>
	
	
<image offsetXPC=5 offsetYPC=6 widthPC=50 heightPC=88><script> print(gLink); </script></image>

<image redraw="no" offsetXPC=60 offsetYPC=2 widthPC=30 heightPC=15>$lpath</image>

<text redraw="no" offsetXPC="56" offsetYPC="18" widthPC="21" heightPC="3" fontSize="12" backgroundColor="-1:-1:-1" foregroundColor="255:255:0">
Street keys:		
</text>

<text redraw="no" offsetXPC="56" offsetYPC="23" widthPC="21" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
[Fast Rewind] = Look left		
</text> 

<text redraw="no" offsetXPC="56" offsetYPC="28" widthPC="21" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
[Fast Forward] = Look right		
</text>

<text redraw="no" offsetXPC="77" offsetYPC="23" widthPC="21" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
[8] = Look up		
</text> 

<text redraw="no" offsetXPC="77" offsetYPC="28" widthPC="21" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
[0] = Look down		
</text> 

<text redraw="no" offsetXPC="56" offsetYPC="33" widthPC="21" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
[Next] = Zoom in		
</text> 

<text redraw="no" offsetXPC="56" offsetYPC="38" widthPC="21" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
[Prev] = Zoom out		
</text> 

<text redraw="no" offsetXPC="77" offsetYPC="33" widthPC="21" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
[Up] = Move forward	
</text> 

<text redraw="no" offsetXPC="77" offsetYPC="38" widthPC="21" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
[Down] = Move backward	
</text> 	



<text redraw="no" offsetXPC="55" offsetYPC="47" widthPC="43" heightPC="3" fontSize="12" backgroundColor="-1:-1:-1" foregroundColor="255:255:0">
Roadmap/Satellite/Terrain/Hybrid keys:
</text> 

<text redraw="no" offsetXPC="56" offsetYPC="52" widthPC="14" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
[Up] = Go north	
</text> 

<text redraw="no" offsetXPC="56" offsetYPC="57" widthPC="14" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
[Down] = Go south	
</text> 	

<text redraw="no" offsetXPC="70" offsetYPC="52" widthPC="13" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
[Right] = Go east	
</text>

<text redraw="no" offsetXPC="70" offsetYPC="57" widthPC="13" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
[Left] = Go west	
</text>

<text redraw="no" offsetXPC="83" offsetYPC="52" widthPC="14" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
[Next] = Zoom in		
</text> 

<text redraw="no" offsetXPC="83" offsetYPC="57" widthPC="14" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
[Prev] = Zoom out		
</text>




<text redraw="no" offsetXPC="55.5" offsetYPC="66" widthPC="21" heightPC="3" fontSize="12" backgroundColor="-1:-1:-1" foregroundColor="255:255:0">
Actual values:
</text> 

<text redraw="no" offsetXPC="56" offsetYPC="71" widthPC="9" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
<script> print("Fov: " + fov); </script>	
</text>

<text redraw="no" offsetXPC="56" offsetYPC="76" widthPC="9" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
<script> print("Zoom: " + zoom); </script>	
</text> 

<text redraw="no" offsetXPC="66" offsetYPC="71" widthPC="13" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
<script> print("Heading: " + head + " &#176;"); </script>	
</text>

<text redraw="no" offsetXPC="66" offsetYPC="76" widthPC="13" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
<script> print("Pitch: " + pit + " &#176;"); </script>
</text> 

<text redraw="no" offsetXPC="55.5" offsetYPC="81" widthPC="21" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
<script> print("Latitude: " + unitLat); </script>	
</text> 

<text redraw="no" offsetXPC="55.5" offsetYPC="86" widthPC="21" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
<script> print("Longitude: " + unitLng); </script>	
</text> 

<text redraw="no" offsetXPC="55.5" offsetYPC="91" widthPC="21" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
<script> print("View: " + mode); </script>
</text> 



<text redraw="no" offsetXPC="80" offsetYPC="66" widthPC="16" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="255:255:0">
View:		
</text>

<text redraw="no" offsetXPC="80" offsetYPC="71" widthPC="16" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
[1] = Roadmap		
</text> 

<text redraw="no" offsetXPC="80" offsetYPC="76" widthPC="16" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
[2] = Satellite		
</text> 

<text redraw="no" offsetXPC="80" offsetYPC="81" widthPC="16" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
[3] = Terrain		
</text>

<text redraw="no" offsetXPC="80" offsetYPC="86" widthPC="16" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
[4] = Hybrid		
</text> 

<text redraw="no" offsetXPC="80" offsetYPC="91" widthPC="16" heightPC="3" fontSize="11" backgroundColor="-1:-1:-1" foregroundColor="130:130:130">
[5] = Street	
</text> 

</backgroundDisplay>

<onUserInput>
        input = currentUserInput();		
		
        if (input == "one") {
		    mode = "roadmap";
			"true";
			redrawDisplay();
        }

        else if (input == "two") {
		    mode = "satellite";
			"true";
			redrawDisplay();
        }
		
        else if (input == "three") {
		    mode = "terrain";
			"true";
			redrawDisplay();
        }

        else if (input == "four") {
		    mode = "hybrid";
			"true";
			redrawDisplay();
        }
		
        else if (input == "five") {
		    mode = "street";
			"true";
			redrawDisplay();
        }		
		
        else if (input == "video_ffwd") {
		    if (head &gt; 350)	{ head = 10;   	}
			else            	{ head = head + 10; }

			"true";
			redrawDisplay();
        }

        else if (input == "video_frwd") {
			if (head &lt; 10)	{ head = 350;   		}
			else            	{ head = head - 10; }
			
			"true";
			redrawDisplay();
        }

        else if (input == "pageup"  &amp;&amp;  mode == "street") {
		    if (fov &gt; 110)	{ fov = 120;   		}
			else            	{ fov = fov + 10; 	}

			"true";
			redrawDisplay();
        }

        else if (input == "pagedown"  &amp;&amp;  mode == "street") {
			if (fov &lt; 30)	{ fov = 20;   		}
			else            	{ fov = fov - 10; 	}
			
			"true";
			redrawDisplay();
        }

		
		
        else if (input == "pageup"  &amp;&amp;  mode != "street") {
		    if (zoom &lt; 1)	{ zoom = 0;   		}
			else            	{ zoom = zoom - 1; 	}

			"true";
			redrawDisplay();
        }

        else if (input == "pagedown"  &amp;&amp;  mode != "street") {
			if (zoom &gt; 20)	{ zoom = 21;   		}
			else            	{ zoom = zoom + 1; 	}
			
			"true";
			redrawDisplay();
        }
		
		
		
        else if (input == "eight") {
		    if (pit &gt; 80)	{ pit = 90;   		}
			else            	{ pit = pit + 10; 	}

			"true";
			redrawDisplay();
        }

        else if (input == "zero") {
			if (pit &lt; -80)	{ pit = -90;   		}
			else            	{ pit = pit - 10; 	}
			
			"true";
			redrawDisplay();
        }
		
  
       else if (input == "up"  &amp;&amp;  mode != "street") {
                loadXMLFile("$rpath/coordcal.php?lat="+unitLat+"&amp;lon="+unitLng+"&amp;heading=0&amp;zoom="+ zoom);
                unitLat=getXMLText("coordinates","latitude");
                unitLng=getXMLText("coordinates","longitude");
		"true";
        } 

      else if (input == "down"  &amp;&amp;  mode != "street") {
                loadXMLFile("$rpath/coordcal.php?lat="+unitLat+"&amp;lon="+unitLng+"&amp;heading=180&amp;zoom="+ zoom);
                unitLat=getXMLText("coordinates","latitude");
                unitLng=getXMLText("coordinates","longitude");
		"true";
        } 

       else if (input == "right"  &amp;&amp;  mode != "street") {
                loadXMLFile("$rpath/coordcal.php?lat="+unitLat+"&amp;lon="+unitLng+"&amp;heading=90&amp;zoom="+ zoom);
                unitLat=getXMLText("coordinates","latitude");
                unitLng=getXMLText("coordinates","longitude");
		"true";
        } 
 
        else if (input == "left"  &amp;&amp;  mode != "street") {
                loadXMLFile("$rpath/coordcal.php?lat="+unitLat+"&amp;lon="+unitLng+"&amp;heading=270&amp;zoom="+ zoom);
                unitLat=getXMLText("coordinates","latitude");
                unitLng=getXMLText("coordinates","longitude");
		"true";
        }

        else if (input == "up"  &amp;&amp;  mode == "street") {
                loadXMLFile("$rpath/coordcal.php?lat="+unitLat+"&amp;lon="+unitLng+"&amp;heading="+head+"&amp;zoom=18");
                unitLat=getXMLText("coordinates","latitude");
                unitLng=getXMLText("coordinates","longitude");
		"true";
        } 

      else if (input == "down"  &amp;&amp;  mode == "street") {
                invhead = 360 - head;
                loadXMLFile("$rpath/coordcal.php?lat="+unitLat+"&amp;lon="+unitLng+"&amp;heading="+invhead+"&amp;zoom=18");
                unitLat=getXMLText("coordinates","latitude");
                unitLng=getXMLText("coordinates","longitude");
		"true";
        }   
        else  {
           "false";
        }
</onUserInput>
</mediaDisplay>


<channel>
<title>GoogleMaps</title>

</channel></rss>
END;
?>
