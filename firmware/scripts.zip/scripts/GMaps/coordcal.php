<?php

/*
# Google Maps (coordinates calculator)
# Author: Snappy46 [levesque.marcel@gmail.com]
# Version: 1.0     
*/

$lat1=$_GET["lat"];
$lon1=$_GET["lon"];
$brng=$_GET["heading"];
$zoom=$_GET["zoom"];

$R=6371000;  //Earth radius in meters approximately
$d=(6371000/pow(2,$zoom)); // distance proportional to the zoom value. 
$latrad1=deg2rad($lat1); //converting latitude from degree to radian
$lonrad1=deg2rad($lon1); //converting longitude from degree to radian
$brngrad=deg2rad($brng); //converting bearing from degree to radian

if (($brng==90) || ($brng==270))
    $latrad2=$latrad1;
else
   $latrad2=asin(sin($latrad1)*cos($d/$R)+cos($latrad1)*sin($d/$R)*cos($brngrad));

$lat2=rad2deg($latrad2); //converting lattitude from radian to degree

$sublat1=sin($latrad1)*cos($d/$R);
$sublat2=sin($latrad1);
$sublat3=cos($d/$R);

if (($brng==0) || ($brng==180))
   $lonrad2=$lonrad1;
else
   $lonrad2 =$lonrad1+atan2(sin($brngrad)*sin($d/$R)*cos($latrad1), cos($d/$R)-sin($latrad1)*sin($latrad2));
//   $lonrad2= fmod($lonrad1-asin(sin($brngrad)*sin($d)/cos($latrad2))+pi(),2*pi())-pi();


$lon2=rad2deg($lonrad2); //converting longitude from radian to degree

echo <<<END
<?xml version="1.0" encoding="UTF-8"?>
<coordinates>
<latitude>$lat2</latitude>
<longitude>$lon2</longitude>
</coordinates>
END;
?>

