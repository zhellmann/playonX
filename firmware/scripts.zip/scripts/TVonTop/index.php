<?php
require_once 'interfaces/view.inc';
require_once 'interfaces/service.inc';

require_once 'tools/config.inc';
require_once 'loader.inc';
require_once 'tools/logger.inc';
require_once 'tools/lang.inc';

session_name("TVonTopSID");
session_id("TVonTopSID123456789");
session_start();

$op   = isset($_GET['op'])   ? $_GET['op']   : "get";
$mode = isset($_GET['mode']) ? $_GET['mode'] : "";
$id   = isset($_GET['id'])   ? $_GET['id']   : null;
$pl   = isset($_GET['pl'])   ? $_GET['pl']   : null;

$loader   = new Loader();
$cfg      = $loader->loadConfig();


//TODO: Do it better
$ttVersion =  "1.?.?";
try {
	$verFile = getcwd() . '/version.xml';
	if (file_exists($verFile)) {
		$verXml  = simplexml_load_file($verFile);
		if(false != $verXml) {
			$ttVersion = (string)$verXml->version;
		} 
	}
} catch(Exception $e) {

}
$cfg->set("version",$ttVersion,  Configuration::$RUNTIME_SECTION);

$log  = Logger::getRootLogger();
$log->setLogLevel($cfg->get("logLevel",null,0));

//set max execution time
$maxExecTime = $cfg->get("max_exec_time", null, '');
if ('' != $maxExecTime) { 
	set_time_limit ($maxExecTime);
} 
// set runtime properties
date_default_timezone_set($cfg->get("timezone", null, 'Europe/Berlin'));
$processingUrl = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];
if (isset($pl)) {
	$processingUrl .= "?pl=$pl";
}
$cfg->set('cfg_processing_url', $processingUrl ,Configuration::$RUNTIME_SECTION);

$cfg->set('cfg_home', 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/", Configuration::$RUNTIME_SECTION);

$cfg->set('cfg_realpath', dirname($_SERVER["SCRIPT_FILENAME"])."/" , Configuration::$RUNTIME_SECTION);


$view     = $loader->loadView($cfg);
$services = $loader->loadServices($cfg);

if (null == $pl || ! isset($services[$pl])) {
	$servicesObj = $loader->getServicesMediaObject($cfg, $services);
	$servicesObj->sortChildren('demoService', 'title');

 	$localeName = $cfg->get("Locale",null,"en_EN");
    $lang = new Lang(); 
    $view->setLocale($lang->getLocale($localeName));
        	
	$view->drawObject($servicesObj, $mode);
} else {
	$cfg->set('currentService', $services[$pl]->getShortName() , Configuration::$RUNTIME_SECTION);
	$services[$pl]->init($cfg);
	$services[$pl]->draw($view, $op, $mode, $id, $_GET);
}
?>
