pref("extensions.playonplayer.player", "player");
