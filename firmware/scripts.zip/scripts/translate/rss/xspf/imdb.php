<?php
if (isset($_GET['name'])) {
  $moviename = strip_tags(trim($_GET['name']));
  $moviename = htmlspecialchars($moviename);
}
else {
  die('Movie name is required!');	
}
echo <<<END
<?xml version="1.0"?>
<rss version="2.0" xmlns:media="http://purl.org/dc/elements/1.1/" xmlns:dc="http://purl.org/dc/elements/1.1/">
<mediaDisplay name="onePartView" drawItemText="no" slidingItemText="no" showHeader="no" showDefaultInfo="no" sliding="no" sideColorLeft="0:0:0" sideColorRight="0:0:0" backgroundColor="0:0:0">
<backgroundDisplay>
<text redraw="no" align="center" offsetXPC="0" offsetYPC="45" widthPC="100" heightPC="10" fontSize="20" backgroundColor="-1:-1:-1" foregroundColor="192:192:192">Loading IMDb  . . .     </text>
END;
echo '<image offsetXPC=0 offsetYPC=0 widthPC=100 heightPC=100>http://playon.unixstorm.org/IMDB/movie.php?name=' . urlencode($moviename) . '&amp;mode=sheet&amp;backdrop=yes</image></backgroundDisplay></mediaDisplay><channel><title>IMDB</title></channel></rss>';
?>