<?php
error_reporting(0);
$a_itags=array(35,34,5); // low
//$a_itags=array(37,22,18);  // 1080
//$a_itags=array(22,18);  // 720 

if(isset($_GET["id"])){
  $id = $_GET["id"];
  $link   = "http://www.youtube.com/watch?v=".$id;
  $html   = file_get_contents($link);
  
 if (preg_match('#config = {(?P<out>.*)};#im', $html, $out)) {

		$parts  = json_decode('{'.$out['out'].'}', true);
		$videos = explode(',', $parts['args']['url_encoded_fmt_stream_map']);

	  foreach ($videos as $video) {
			$vid = urldecode(urldecode($video));
			$vid = str_replace(array('sig=', '---'), array('signature=', '.'), $vid);
			parse_str($vid, $output);

			if (in_array($output['itag'], $a_itags)) break;
		}

		$path = preg_replace('/^(.*\?)((itag|fexp|type|mv|sver|mt|ms|quality|codecs|fallback_host)=(.*))$/iU', '$1', $output['url'].'&');

	  unset($output['url']);
		if (isset($output['fexp']))          unset($output['fexp']);
		if (isset($output['type']))          unset($output['type']);
		if (isset($output['mv']))            unset($output['mv']);
		if (isset($output['sver']))          unset($output['sver']);
		if (isset($output['mt']))            unset($output['mt']);
		if (isset($output['ms']))            unset($output['ms']);
		if (isset($output['quality']))       unset($output['quality']);
		if (isset($output['codecs']))        unset($output['codecs']);
		if (isset($output['fallback_host'])) unset($output['fallback_host']);

		$link = urldecode($path.http_build_query($output));
		print $link;
  } 
 }
die();
?>