<?php

/* 
Name: SysInfo PHP/RSS script for Realtek media players (http://playon.unixstorm.org/sysinfo.php)
Created by: Zbigniew 'mikka' Hellmann (root@playon.unixstorm.org)
 
Based on: phpSysInfo 3.0 (http://phpsysinfo.sourceforge.net)
Created by: Uriah Welcome (precision@users.sf.net), Michael Cramer (bigmichi1@users.sf.net), Audun Larsen (xqus@users.sf.net), Erkan Valentin (jacky672@users.sf.net), Mieczyslaw Nalewaj (namiltd@users.sf.net)
*/ 

# Set your timezone here
date_default_timezone_set('UTC');

# Set your language here
$lang = 'en';

# Set path to SysInfo here
$path = '/home/scripts/sysinfo/';


function secondsToTime($s)
{
	$d = intval($s/86400);
	$s -= $d*86400;

	$h = intval($s/3600);
	$s -= $h*3600;

	$m = intval($s/60);
	$s -= $m*60;

    $obj = array(
        "d" => $d,	
        "h" => $h,
        "m" => $m,
        "s" => $s,
    );
    return $obj;
}

function bytesToSize($bytes, $precision = 2)
{  
    $kilobyte = 1024;
    $megabyte = $kilobyte * 1024;
    $gigabyte = $megabyte * 1024;
    $terabyte = $gigabyte * 1024;
   
    if (($bytes >= 0) && ($bytes < $kilobyte)) {
        return $bytes . ' B';
 
    } elseif (($bytes >= $kilobyte) && ($bytes < $megabyte)) {
        return round($bytes / $kilobyte, $precision) . ' KB';
 
    } elseif (($bytes >= $megabyte) && ($bytes < $gigabyte)) {
        return round($bytes / $megabyte, $precision) . ' MB';
 
    } elseif (($bytes >= $gigabyte) && ($bytes < $terabyte)) {
        return round($bytes / $gigabyte, $precision) . ' GB';
 
    } elseif ($bytes >= $terabyte) {
        return round($bytes / $terabyte, $precision) . ' TB';
    } else {
        return $bytes . ' B';
    }
}

# Get language data
$xml =  simplexml_load_file("language/" . $lang . ".xml");
$langtitle = $xml->expression[0]->exp;
$langvitals = $xml->expression[1]->exp;
$langhostname = $xml->expression[2]->exp;
$langip = $xml->expression[3]->exp;
$langkversion = $xml->expression[4]->exp;
$languptime = $xml->expression[6]->exp;
$langloadavg = $xml->expression[8]->exp;
$langnetusage = $xml->expression[20]->exp;
$langdevice = $xml->expression[21]->exp;
$langreceived = $xml->expression[22]->exp;
$langsent = $xml->expression[23]->exp;
$langmemusage = $xml->expression[26]->exp;
$langphymem = $xml->expression[27]->exp;
$langswap = $xml->expression[28]->exp;
$langfs = $xml->expression[29]->exp;
$langmount = $xml->expression[30]->exp;
$langpartition = $xml->expression[31]->exp;
$langpercent = $xml->expression[32]->exp;
$langtype = $xml->expression[33]->exp;
$langfree = $xml->expression[34]->exp;
$langused = $xml->expression[35]->exp;
$langsize = $xml->expression[36]->exp;
$langtotals = $xml->expression[37]->exp;
$langdays = $xml->expression[47]->exp;
$langhours = $xml->expression[48]->exp;
$langminutes = $xml->expression[49]->exp;
$langbuffers = $xml->expression[64]->exp;
$langcached = $xml->expression[65]->exp;

$arr = array();

# Listening IP
$arr['ip'] = file_get_contents('http://playon.unixstorm.org/sysinfo/ip.php');

# Canonical Hostname
$arr['hostname'] = gethostbyaddr($arr['ip']);

# Kernel Version
exec('uname -r', $data);
$arr['kernel'] = $data[0];
unset($data);

# Uptime
exec('cat /proc/uptime', $data);
$uptime = secondsToTime(round($data[0]));
$arr['uptime'] = $uptime['d'] . ' ' . $langdays . ' ' . $uptime['h'] . ' ' . $langhours . ' ' . $uptime['m'] . ' ' . $langminutes;
unset($data);

# Load Averages
exec('cat /proc/loadavg', $data);
$arr['loadavg'] = $data[0];
unset($data);

# Network Usage
$arr['interface'] = array();
$arr['rbytes'] = array();
$arr['tbytes'] = array();
$arr['allbytes'] = array();

exec('cat /proc/net/dev', $data);
foreach($data as $line)
{
	if (preg_match('/([\w\d]+):\s*(\d+)\s+(\d+)\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+(\d+)\s+(\d+)\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+/', $line, $m))
	{
		$total = $m[2] + $m[4];
		array_push($arr['interface'], $m[1]);
		array_push($arr['rbytes'], $m[2]);
		array_push($arr['tbytes'], $m[4]);
		array_push($arr['allbytes'], $total);
	}
}
unset($data);
	

# Memory Usage
exec('cat /proc/meminfo', $data);
foreach($data as $line)
{
    $array = explode(':', str_replace (' ', '', $line) );
    $value = preg_replace('/kb/i', '', $array[1]);
    if (preg_match ('/^MemTotal/', $line))
        $arr['memtotal'] = ($value*1024);
 
    elseif (preg_match ('/^MemFree/', $line ))
        $arr['memfree'] = ($value*1024);
 
    elseif (preg_match ('/^Buffers/', $line))
         $arr['buffers'] = ($value*1024);
 
    elseif (preg_match ('/^Cached/', $line))
        $arr['cached'] = ($value*1024);
 
    elseif (preg_match ('/^SwapTotal/', $line))
        $arr['swaptotal'] = ($value*1024);
		
    elseif (preg_match ('/^SwapFree:/', $line))
        $arr['swapfree'] = ($value*1024);
}
$arr['mem'] = ($arr['memtotal'] - $arr['memfree']);
$arr['swap'] = ($arr['swaptotal'] - $arr['swapfree']);
$arr['memusage'] = round((($arr['mem'] / $arr['memtotal'])*100));
$arr['buffersusage'] = round((($arr['buffers'] / $arr['memtotal'])*100));
$arr['cachedusage'] = round((($arr['cached'] / $arr['memtotal'])*100));
$arr['swapusage'] = round((($arr['swap'] / $arr['swaptotal'])*100));
unset($data);


# Mounted Filesystems
$arr['mountpoint'] = array();
$arr['type'] = array();
$arr['partition'] = array();
$arr['mountpercent'] = array();
$arr['mountfree'] = array();
$arr['mountused'] = array();
$arr['mountsize'] = array();

exec('cat /proc/mounts', $data);
foreach($data as $line)
{
	$m = explode(" ", $line);
	if (($m[0] !== 'none') && ($m[0] !== 'rootfs') && ($m[0] !== 'devpts'))
	{
		$free_space = disk_free_space($m[1]);
		$total_space = disk_total_space($m[1]);
		$used_space = $total_space - $free_space;
		$percent_space = round((($used_space / $total_space)*100));
		
		array_push($arr['mountpoint'], $m[1]);
 		array_push($arr['type'], $m[2]);
		array_push($arr['partition'], $m[0]);
		array_push($arr['mountpercent'], $percent_space);
	 	array_push($arr['mountfree'], $free_space);
		array_push($arr['mountused'], $used_space);
 		array_push($arr['mountsize'], $total_space);
	}
}
unset($data);

$arr['now'] = 'Created by SysInfo on ' . date('F j, Y \a\t g:i A');

//print_r($arr);


echo '<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0" xmlns:media="http://purl.org/dc/elements/1.1/" xmlns:dc="http://purl.org/dc/elements/1.1/">
<mediaDisplay name="onePartView" drawItemText="no" slidingItemText="no" showHeader="no" showDefaultInfo="no" backgroundColor="0:0:0" sliding="no" idleImageXPC="90" idleImageYPC="90" idleImageWidthPC="5" idleImageHeightPC="5" sideColorRight="0:0:0" sideColorLeft="0:0:0" sideColorTop="0:0:0" sideColorBottom="0:0:0">
        <idleImage>' . $path . 'image/IMAGE_BW_LOGO_LOADING_0.png</idleImage>
        <idleImage>' . $path . 'image/IMAGE_BW_LOGO_LOADING_1.png</idleImage>
        <idleImage>' . $path . 'image/IMAGE_BW_LOGO_LOADING_2.png</idleImage>
        <idleImage>' . $path . 'image/IMAGE_BW_LOGO_LOADING_3.png</idleImage>
        <idleImage>' . $path . 'image/IMAGE_BW_LOGO_LOADING_4.png</idleImage>
        <idleImage>' . $path . 'image/IMAGE_BW_LOGO_LOADING_5.png</idleImage>
        <idleImage>' . $path . 'image/IMAGE_BW_LOGO_LOADING_6.png</idleImage>
        <idleImage>' . $path . 'image/IMAGE_BW_LOGO_LOADING_7.png</idleImage>
        <idleImage>' . $path . 'image/IMAGE_BW_LOGO_LOADING_8.png</idleImage>
		
<backgroundDisplay>
<image offsetXPC="3" offsetYPC="90" widthPC="7" heightPC="5">' . $path . 'image/ffwd.bmp</image>
';

if (isset($_GET['mount']))
{
echo '
<image offsetXPC="2" offsetYPC="5" widthPC="96" heightPC="82">' . $path . 'image/panel.png</image>
	
<text offsetXPC="3" offsetYPC="8" widthPC="35" heightPC="5" fontSize="13" foregroundColor="255:255:255">' . $langfs . '</text>

<text offsetXPC="4" offsetYPC="19" widthPC="15" heightPC="5" fontSize="11" foregroundColor="139:123:139">' . $langmount . '</text>
<text offsetXPC="20" offsetYPC="19" widthPC="10" heightPC="5" fontSize="11" foregroundColor="139:123:139">' . $langtype . '</text>
<text offsetXPC="30" offsetYPC="19" widthPC="15" heightPC="5" fontSize="11" foregroundColor="139:123:139">' . $langpartition . '</text>
<text offsetXPC="45" offsetYPC="19" widthPC="20" heightPC="5" fontSize="11" foregroundColor="139:123:139">' . $langpercent . '</text>
<text offsetXPC="65" offsetYPC="19" widthPC="10" heightPC="5" fontSize="11" foregroundColor="139:123:139">' . $langfree . '</text>
<text offsetXPC="75" offsetYPC="19" widthPC="10" heightPC="5" fontSize="11" foregroundColor="139:123:139">' . $langused . '</text>
<text offsetXPC="85" offsetYPC="19" widthPC="10" heightPC="5" fontSize="11" foregroundColor="139:123:139">' . $langsize . '</text>
';

$nr = 0;
$ypos = 24;
$ipos = 25.5;
foreach($arr['mountpoint'] as $id)
{
	$srodek = (($arr['mountpercent'][$nr] * 11) / 100)+1;
	$prawy = $srodek + 45;
	$napis = $prawy + 2;
	
	echo '
<text offsetXPC="4" offsetYPC="' . $ypos . '" widthPC="10" heightPC="5" fontSize="11" foregroundColor="255:255:255" lines="2">' . $arr['mountpoint'][$nr] . '</text>
<text offsetXPC="20" offsetYPC="' . $ypos . '" widthPC="10" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . $arr['type'][$nr] . '</text>
<text offsetXPC="30" offsetYPC="' . $ypos . '" widthPC="15" heightPC="5" fontSize="11" foregroundColor="255:255:255" lines="2">' . $arr['partition'][$nr] . '</text>
<image offsetXPC="45" offsetYPC="' . $ipos . '" widthPC="1" heightPC="1.8">' . $path . 'image/bar_left.png</image>
<image offsetXPC="46" offsetYPC="' . $ipos . '" widthPC="' . $srodek  . '" heightPC="1.8">' . $path . 'image/bar_middle.png</image>
<image offsetXPC="'. $prawy . '" offsetYPC="' . $ipos . '" widthPC="1" heightPC="1.8">' . $path . 'image/bar_right.png</image>

<text offsetXPC="' . $napis . '" offsetYPC="' . $ypos . '" widthPC="10" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . $arr['mountpercent'][$nr] . '%</text>

<text offsetXPC="65" offsetYPC="' . $ypos . '" widthPC="10" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . bytesToSize($arr['mountfree'][$nr]) . '</text>
<text offsetXPC="75" offsetYPC="' . $ypos . '" widthPC="10" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . bytesToSize($arr['mountused'][$nr]) . '</text>
<text offsetXPC="85" offsetYPC="' . $ypos . '" widthPC="10" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . bytesToSize($arr['mountsize'][$nr]) . '</text>';

	$ypos = $ypos + 8;
	$ipos = $ipos + 8;
	$nr++;
}

echo '
<text offsetXPC="9" offsetYPC="90" widthPC="80" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . $langvitals . ', ' . $langnetusage . ', ' . $langmemusage . '</text>
';

$sLink = 'http://' . $_SERVER['SERVER_ADDR'] . ":" . $_SERVER['SERVER_PORT'] . dirname($_SERVER['PHP_SELF']) . '/sysinfo.php';
}



else {
echo '
<image offsetXPC="2" offsetYPC="12" widthPC="47" heightPC="35">' . $path . 'image/panel.png</image>
<image offsetXPC="51" offsetYPC="12" widthPC="47" heightPC="35">' . $path . 'image/panel.png</image>
<image offsetXPC="2" offsetYPC="51" widthPC="96" heightPC="35">' . $path . 'image/panel.png</image>

<text offsetXPC="0" offsetYPC="2" widthPC="98" heightPC="8" fontSize="17" foregroundColor="255:255:255" align="center">' . $langtitle . ': ' . $arr['hostname'] . ' (' . $arr['ip'] . ')</text>

<text offsetXPC="3" offsetYPC="12" widthPC="35" heightPC="5" fontSize="13" foregroundColor="255:255:255">' . $langvitals . '</text>

<text offsetXPC="4" offsetYPC="19" widthPC="15" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . $langhostname . '</text>
<text offsetXPC="20" offsetYPC="19" widthPC="35" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . $arr['hostname'] . '</text>
	
<text offsetXPC="4" offsetYPC="24" widthPC="15" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . $langip . '</text>
<text offsetXPC="20" offsetYPC="24" widthPC="35" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . $arr['ip'] . '</text>

<text offsetXPC="4" offsetYPC="29" widthPC="15" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . $langkversion . '</text>
<text offsetXPC="20" offsetYPC="29" widthPC="35" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . $arr['kernel'] . '</text>

<text offsetXPC="4" offsetYPC="34" widthPC="15" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . $languptime . '</text>
<text offsetXPC="20" offsetYPC="34" widthPC="35" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . $arr['uptime'] . '</text>

<text offsetXPC="4" offsetYPC="39" widthPC="15" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . $langloadavg . '</text>
<text offsetXPC="20" offsetYPC="39" widthPC="35" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . $arr['loadavg'] . '</text>


<text offsetXPC="52" offsetYPC="12" widthPC="35" heightPC="5" fontSize="13" foregroundColor="255:255:255">' . $langnetusage . '</text>
<text offsetXPC="53" offsetYPC="19" widthPC="10" heightPC="5" fontSize="11" foregroundColor="139:123:139">' . $langdevice . '</text>
<text offsetXPC="63" offsetYPC="19" widthPC="10" heightPC="5" fontSize="11" foregroundColor="139:123:139">' . $langreceived . '</text>
<text offsetXPC="73" offsetYPC="19" widthPC="10" heightPC="5" fontSize="11" foregroundColor="139:123:139">' . $langsent . '</text>
<text offsetXPC="83" offsetYPC="19" widthPC="10" heightPC="5" fontSize="11" foregroundColor="139:123:139">' . $langtotals . '</text>';
	
$nr = 0;
$ypos = 24;
foreach($arr['interface'] as $id)
{
	echo '
<text offsetXPC="53" offsetYPC="' . $ypos . '" widthPC="10" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . $arr['interface'][$nr] . '</text>
<text offsetXPC="63" offsetYPC="' . $ypos . '" widthPC="10" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . bytesToSize($arr['rbytes'][$nr]) . '</text>
<text offsetXPC="73" offsetYPC="' . $ypos . '" widthPC="10" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . bytesToSize($arr['tbytes'][$nr]) . '</text>
<text offsetXPC="83" offsetYPC="' . $ypos . '" widthPC="10" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . bytesToSize($arr['allbytes'][$nr]) . '</text>';

	$ypos = $ypos + 5;
	$nr++;
}
		
echo '		
<text offsetXPC="3" offsetYPC="51" widthPC="35" heightPC="5" fontSize="13" foregroundColor="255:255:255">' . $langmemusage . '</text>

<text offsetXPC="4" offsetYPC="58" widthPC="15" heightPC="5" fontSize="11" foregroundColor="139:123:139">' . $langtype . '</text>
<text offsetXPC="20" offsetYPC="58" widthPC="20" heightPC="5" fontSize="11" foregroundColor="139:123:139">' . $langpercent . '</text>
<text offsetXPC="65" offsetYPC="58" widthPC="10" heightPC="5" fontSize="11" foregroundColor="139:123:139">' . $langfree . '</text>
<text offsetXPC="75" offsetYPC="58" widthPC="10" heightPC="5" fontSize="11" foregroundColor="139:123:139">' . $langused . '</text>
<text offsetXPC="85" offsetYPC="58" widthPC="10" heightPC="5" fontSize="11" foregroundColor="139:123:139">' . $langsize . '</text>

<text offsetXPC="4" offsetYPC="63" widthPC="15" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . $langphymem . '</text>
<image offsetXPC="20" offsetYPC="64.5" widthPC="1" heightPC="1.8">' . $path . 'image/bar_left.png</image>';

$srodek = (($arr['memusage'] * 29) / 100)+1;
$prawy = $srodek + 20;
$napis = $prawy + 2;

echo '
<image offsetXPC="21" offsetYPC="64.5" widthPC="' . $srodek  . '" heightPC="1.8">' . $path . 'image/bar_middle.png</image>
<image offsetXPC="'. $prawy . '" offsetYPC="64.5" widthPC="1" heightPC="1.8">' . $path . 'image/bar_right.png</image>
<text offsetXPC="' . $napis . '" offsetYPC="63" widthPC="10" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . $arr['memusage'] . '%</text>
<text offsetXPC="65" offsetYPC="63" widthPC="10" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . bytesToSize($arr['memfree']) . '</text>
<text offsetXPC="75" offsetYPC="63" widthPC="10" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . bytesToSize($arr['mem']) . '</text>
<text offsetXPC="85" offsetYPC="63" widthPC="10" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . bytesToSize($arr['memtotal']) . '</text>

<text offsetXPC="4" offsetYPC="68" widthPC="15" heightPC="5" fontSize="11" foregroundColor="255:255:255">- ' . $langbuffers . '</text>
<image offsetXPC="20" offsetYPC="69.5" widthPC="1" heightPC="1.8">' . $path . 'image/bar_left.png</image>';

$srodek = (($arr['buffersusage'] * 29) / 100)+1;
$prawy = $srodek + 20;
$napis = $prawy + 2;

echo '
<image offsetXPC="21" offsetYPC="69.5" widthPC="' . $srodek  . '" heightPC="1.8">' . $path . 'image/bar_middle.png</image>
<image offsetXPC="'. $prawy . '" offsetYPC="69.5" widthPC="1" heightPC="1.8">' . $path . 'image/bar_right.png</image>
<text offsetXPC="' . $napis . '" offsetYPC="68" widthPC="10" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . $arr['buffersusage']. '%</text>
<text offsetXPC="75" offsetYPC="68" widthPC="10" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . bytesToSize($arr['buffers'])  . '</text>

<text offsetXPC="4" offsetYPC="73" widthPC="15" heightPC="5" fontSize="11" foregroundColor="255:255:255">- ' . $langcached . '</text>
<image offsetXPC="20" offsetYPC="74.5" widthPC="1" heightPC="1.8">' . $path . 'image/bar_left.png</image>';

$srodek = (($arr['cachedusage'] * 29) / 100)+1;
$prawy = $srodek + 20;
$napis = $prawy + 2;

echo '
<image offsetXPC="21" offsetYPC="74.5" widthPC="' . $srodek  . '" heightPC="1.8">' . $path . 'image/bar_middle.png</image>
<image offsetXPC="'. $prawy . '" offsetYPC="74.5" widthPC="1" heightPC="1.8">' . $path . 'image/bar_right.png</image>
<text offsetXPC="' . $napis . '" offsetYPC="73" widthPC="10" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . $arr['cachedusage']. '%</text>
<text offsetXPC="75" offsetYPC="73" widthPC="10" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . bytesToSize($arr['cached'])  . '</text>

<text offsetXPC="4" offsetYPC="78" widthPC="15" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . $langswap . '</text>
<image offsetXPC="20" offsetYPC="79.5" widthPC="1" heightPC="1.8">' . $path . 'image/bar_left.png</image>';

$srodek = (($arr['swapusage'] * 29) / 100)+1;
$prawy = $srodek + 20;
$napis = $prawy + 2;

echo '
<image offsetXPC="21" offsetYPC="79.5" widthPC="' . $srodek  . '" heightPC="1.8">' . $path . 'image/bar_middle.png</image>
<image offsetXPC="'. $prawy . '" offsetYPC="79.5" widthPC="1" heightPC="1.8">' . $path . 'image/bar_right.png</image>
<text offsetXPC="' . $napis . '" offsetYPC="78" widthPC="10" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . $arr['swapusage']. '%</text>
<text offsetXPC="65" offsetYPC="78" widthPC="10" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . bytesToSize($arr['swapfree']) . '</text>
<text offsetXPC="75" offsetYPC="78" widthPC="10" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . bytesToSize($arr['swap']) . '</text>
<text offsetXPC="85" offsetYPC="78" widthPC="10" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . bytesToSize($arr['swaptotal']) . '</text>

<text offsetXPC="9" offsetYPC="90" widthPC="80" heightPC="5" fontSize="11" foregroundColor="255:255:255">' . $langfs . '</text>
';

$sLink = 'http://' . $_SERVER['SERVER_ADDR'] . ":" . $_SERVER['SERVER_PORT'] . dirname($_SERVER['PHP_SELF']) . '/sysinfo.php?mount';
}

echo '
</backgroundDisplay>

<onUserInput>
<script>
	userInput = currentUserInput();

	if ( userInput == "return" || userInput == "RET" ) {
		showIdle();
		jumpToLink("sMenu");
		"true";
		redrawDisplay();
	}
	
	if ( userInput == "video_ffwd" ) {
		showIdle();
		jumpToLink("sLink");
		"true";
		redrawDisplay();
	}

"false";
</script>
</onUserInput>
</mediaDisplay>

<sLink><link>' . $sLink . '</link></sLink>
<sMenu><link>' . 'http://' . $_SERVER['SERVER_ADDR'] . ":" . $_SERVER['SERVER_PORT'] . '/menu.rss</link></sMenu>
  
<channel>
<title>SysInfo</title>
			
  </channel>
</rss>';
?>