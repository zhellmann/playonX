<?php
function str_between($string, $start, $end){
	$string = " ".$string; $ini = strpos($string,$start);
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}

$t=$_GET["t"];

$html=file_get_contents("http://www.google.com/search?q=imdb.com+" . rawurlencode($t));
$ttn=str_between($html, "/title/tt", "/");

$ttn="tt".$ttn;

$html=file_get_contents("http://imdb.com/title/".$ttn);

$ttxml="";
//exec ("rm -f /tmp/movie.dat");
$t1=explode('id="img_primary">',$html);
$t2=explode('src="',$t1[1]);
$t3=explode('"',$t2[1]);
$img=$t3[0];

$t1=explode('<h1 class="header"',$html);
$t2=explode('>',$t1[1]);
$t3=explode('<',$t2[1]);
$tit=trim($t3[0]);
$tit=str_replace("&#x22;","'",$tit);
$tit=str_replace("&#x27;","'",$tit);
$tit=str_replace("&nbsp;"," ",$tit);
$tit=str_replace("&raquo;",">>",$tit);
$tit=str_replace("&#xE9;","e",$tit);
$tit=str_replace("&#xCE;","I",$tit);
$tit=str_replace("&#xEE;","i",$tit);

$imdb="IMDB: ".trim(str_between($html,'ratingValue">','<'));
$gen=str_between($html,'div class="infobar">','</div>');

$gen=trim(preg_replace("/(<\/?)(\w+)([^>]*>)/e","",$gen));
$gen=str_replace("&nbsp;"," ",$gen);
$gen=str_replace(" | ",", ",$gen);
$gen=str_replace("  "," ",$gen);
$gen=str_replace("-","",$gen);
$gen=str_replace("\n","",$gen);

$desc=trim(str_between($html,'<p itemprop="description">',"</p>"));
$desc=str_replace("&#x22;","'",$desc);
$desc=str_replace("&#x27;","'",$desc);
$desc=str_replace("&nbsp;"," ",$desc);
$desc=str_replace("&raquo;",">>",$desc);
$desc=str_replace("&#xE9;","e",$desc);
$desc=str_replace("&#xCE;","I",$desc);
$desc=str_replace("&#xEE;","i",$desc);

$desc = trim(preg_replace("/<(.*)>|(\{(.*)\})/e","",$desc));

$ttxml .=$tit."\n"; //title
$ttxml .= "\n";     //an
$ttxml .=$img."\n"; //image
$ttxml .=$gen."\n"; //gen
$ttxml .="\n"; //regie
$ttxml .=$imdb."\n"; //imdb
$ttxml .="\n"; //actori
$ttxml .=$desc."\n"; //descriere
echo $ttxml; //debug
$new_file = "/tmp/movie.dat";
$fh = fopen($new_file, 'w');
fwrite($fh, $ttxml);
fclose($fh);
?>

