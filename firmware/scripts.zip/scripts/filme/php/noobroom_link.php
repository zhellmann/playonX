<?php
require_once(dirname(__FILE__) . '/noobroom_sip.php');

function str_between($string, $start, $end){ 
	$string = " ".$string; $ini = strpos($string,$start); 
	if ($ini == 0) return ""; $ini += strlen($start); $len = strpos($string,$end,$ini) - $ini; 
	return substr($string,$ini,$len); 
}

$ip = $_GET["ip"];
//http://".$ip."/?292
//http://".$ip."/views.php?f=292&_=1348139001110
$query = $_GET["file"];
$queryArr = explode(',', $query);
$id = $queryArr[0];
$subtitle = $queryArr[1];
$server = $queryArr[2];
$hd = $queryArr[3];
//http://".$ip."/?1150&s=6&hd=1
if ($hd =="1") {
  $h=file_get_contents("http://".$ip."/?".$id);
  if (strpos($h,"Watch in 1080p") === false) $hd=0;
}
if ($server == "0") {
  if ($hd=="1")
    $link="http://".$ip."/?".$id."&hd=".$hd;
  else
    $link="http://".$ip."/?".$id;
} else {
  if ($hd=="1")
    $link="http://".$ip."/?".$id."&s=".$server."&hd=".$hd;
  else
    $link="http://".$ip."/?".$id."&s=".$server;
}
//echo $link."<BR>";
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $link);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch,CURLOPT_REFERER,"http://".$ip."/azlist.php");
  $html = curl_exec($ch);
  curl_close($ch);
$s=str_between($html,'streamer": "','"');
$f=str_between($html,'file": "','"');
$movie=$s."&file=".$f;
//echo $movie."<BR>";
$l1="http://".$ip."/views.php?f=".$id;
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $l1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_HEADER, 1);
  curl_setopt($ch, CURLOPT_NOBODY, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch,CURLOPT_REFERER,$link);
  $html = curl_exec($ch);
  curl_close($ch);

if (($server == "0") || (!isset($server))) {
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $movie);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_HEADER, 1);
  curl_setopt($ch, CURLOPT_NOBODY, 1);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 GTB5');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
  curl_setopt($ch,CURLOPT_REFERER,$movie);
  $html = curl_exec($ch);
  curl_close($ch);
  $movie=trim(str_between($html,"Location:","&"))."&start=0&type=flv&hd=0&auth=0&tv=0";
} else {
   $movie="http://".$sip[$server]."/index.php?file=".$id."&start=0&type=flv&hd=".$hd."&auth=0&tv=0";
}
print $movie;
?>
