Musics by Löhstana David
Licence Creative commons
http://creativecommons.org/licenses/by/3.0/

For full quality and full song, you must download the original version
http://www.jamendo.com/fr/album/92150

Info.mp3 "Elle est ainsi"
Score.mp3 "Je sais"

Other songs are vocals and created with a synthesizer by Pooppys and Lili from GeekyHMB team
Geekyhmb.fr.cr
