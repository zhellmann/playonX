<?php

// define RSS menu
$nav_rss['glavtv'] = array (
    'module'=> 'glavtv',
    'rss'   => getMosUrl(). 'modules/glavtv/index.php',
    'icon'  => 'logo.png',
    'title' => 'GlavTV'
);

?>
