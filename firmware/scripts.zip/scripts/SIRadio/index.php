<?php

# Name:   Shoutcast/Icecast radio for Realtek media players
# Author: Zbigniew 'mikka' Hellmann
# WWW:	  http://playon.unixstorm.org/siradio.php

# Turn off error reporting
error_reporting(0);

$favfile='/home/scripts/SIRadio/favorites.list'; 

# Shoutcast API key from A.C. Ryan firmware
$key = 'sh1TWCEbGXk5ufet';

function RandomFile($folder='', $extensions='.*')	{
    $folder = trim($folder);
    $folder = ($folder == '') ? './' : $folder;
	
    if (!is_dir($folder))
		die('invalid folder given!'); 
    $files = array();

    if ($dir = @opendir($folder))	{
        while($file = readdir($dir))	{
            if (!preg_match('/^\.+$/', $file) and preg_match('/\.('.$extensions.')$/', $file))
                $files[] = $file;                          
        }        
        closedir($dir);    
    }
    else
        die('Could not open the folder "'.$folder.'"');

    if (count($files) == 0)
        die('No files where found :-(');
 
    mt_srand((double)microtime()*1000000);
    $rand = mt_rand(0, count($files)-1);
	
    if (!isset($files[$rand]))
        die('Array index was not found! very strange!');
		
    return $folder . $files[$rand];
}



function StationsList($shoutcast, $mytype) {
echo <<<HEAD
<?xml version='1.0' ?><rss version="2.0" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:media="http://purl.org/dc/elements/1.1/">

<mediaDisplay name="onePartView" showHeader="no" rowCount="5" columnCount="1" columnPerPage="1" drawItemText="no" showDefaultInfo="no" itemXPC="10" itemYPC="18" sliding="yes" itemPerPage="7" itemGapYPC="2" itemBorderColor="64:64:255" itemHeightPC="10.5" itemWidthPC="80" itemBackgroundColor="0:0:0" idleImageXPC="90" idleImageYPC="5" idleImageWidthPC="5" idleImageHeightPC="8" backgroundColor="0:0:0" sideTopHeightPC="0" sideColorBottom="-1:-1:-1" sideColorTop="-1:-1:-1" sideColorLeft="0:0:0" sideColorRight="0:0:0" mainPartColor="0:0:0" imageFocus=null imageUnFocus=null imageParentFocus=null >

<idleImage>/home/scripts/SIRadio/layout/loading_0.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_1.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_2.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_3.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_4.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_5.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_6.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_7.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_8.png</idleImage>

<itemDisplay>
<image redraw="yes" offsetXPC="0" offsetYPC="0" widthPC="100" heightPC="100" >
<script>
	if ( getFocusItemIndex() == getItemInfo(-1, "nr") )
		"/home/scripts/SIRadio/layout/MenuItemFO.png";
	else
		"/home/scripts/SIRadio/layout/MenuItemNF.png";
</script>
</image>

<text redraw="no" offsetXPC="1" offsetYPC="0" widthPC="5" heightPC="100" fontSize="13" foregroundColor="255:255:255">
<script>
  numer = getItemInfo(-1, "nr");
  Add(1, numer);
</script>
</text>

<text redraw="no" offsetXPC="5" offsetYPC="1" widthPC="50" heightPC="60" fontSize="13" foregroundColor="255:255:255">
<script>
	getItemInfo(-1, "name");
</script>
</text>

<text redraw="no" offsetXPC="5" offsetYPC="61" widthPC="50" heightPC="39" fontSize="11" foregroundColor="192:192:192">
<script>
	"Now playing: " + getItemInfo(-1, "now");
</script>
</text>

<text redraw="no" offsetXPC="61" offsetYPC="0" widthPC="10" heightPC="100" fontSize="11" foregroundColor="192:192:192">
<script>
	getItemInfo(-1, "bitrate");
</script>
</text>

<text redraw="no" offsetXPC="76" offsetYPC="0" widthPC="10" heightPC="100" fontSize="11" foregroundColor="192:192:192">
<script>
	getItemInfo(-1, "listeners");
</script>
</text>

<text redraw="no" offsetXPC="88" offsetYPC="0" widthPC="10" heightPC="100" fontSize="11" foregroundColor="192:192:192">
<script>
	getItemInfo(-1, "id");
</script>
</text>
</itemDisplay>

<backgroundDisplay>
<image redraw="no" offsetXPC="0" offsetYPC="0" widthPC="100" heightPC="100">/home/scripts/SIRadio/layout/shoutcast_background.jpg</image>
<image redraw="no" offsetXPC="5" offsetYPC="5" widthPC="90" heightPC="92">/home/scripts/SIRadio/layout/shoutcast_list.png</image>

<text redraw="no" offsetXPC="15" offsetYPC="11" widthPC="50" heightPC="5" fontSize="14" backgroundColor="0:0:0" foregroundColor="253:193:0">
Station : [Info] -> Add To Favorites
</text>

<text redraw="no" offsetXPC="58.5" offsetYPC="11" widthPC="10" heightPC="5" fontSize="14" backgroundColor="0:0:0" foregroundColor="253:193:0">
Bitrate
</text>

<text redraw="no" offsetXPC="69" offsetYPC="11" widthPC="10" heightPC="5" fontSize="14" backgroundColor="0:0:0" foregroundColor="253:193:0">
Listeners
</text>

<text redraw="no" offsetXPC="80.5" offsetYPC="11" widthPC="10" heightPC="5" fontSize="14" backgroundColor="0:0:0" foregroundColor="253:193:0">
ID
</text>
</backgroundDisplay>

HEAD;

echo '<onUserInput>
<script>
	userInput = currentUserInput();
	Current_Item = getFocusItemIndex();
		
	if (userInput == "display" || userInput == "DISPLAY") {
		f_name = getItemInfo(Current_Item, "name");
		f_id = getItemInfo(Current_Item, "id");
		cmdl = urlencode(f_name + "|'.$mytype.'|" + f_id);
		url = "http://127.0.0.1:82/SIRadio/index.php?add=" + cmdl;
		doModalRss(url);
		"true";
		redrawDisplay();
	}
';

if ($shoutcast == TRUE)	{
echo <<<SHOUT

	if ( userInput == "video_frwd" ) {
		New = Add(-10, Current_Item);
		if ( New &lt; 0 )	{ setFocusItemIndex(0); 	}
		else				{ setFocusItemIndex(New);	}	
		"true";
		redrawDisplay();
	} 
				
	if ( userInput == "video_ffwd" ) {
		New = Add(10, Current_Item);
		if ( New &gt; 99 )	{ setFocusItemIndex(99); 	}
		else				{ setFocusItemIndex(New);	}	
		"true";
		redrawDisplay();
	}
	
	if ( userInput == "pageup" ) {
		New = Add(-25, Current_Item);
		if ( New &lt; 0 )	{ setFocusItemIndex(0); 	}
		else				{ setFocusItemIndex(New);	}	
		"true";
		redrawDisplay();
	} 
				
	if ( userInput == "pagedown" ) {
		New = Add(25, Current_Item);
		if ( New &gt; 99 )	{ setFocusItemIndex(99); 	}
		else				{ setFocusItemIndex(New);	}	
		"true";
		redrawDisplay();
	}
SHOUT;
}
echo '
</script>
</onUserInput>
</mediaDisplay>
<channel>
';
}



function GenresList($style)	{
echo <<<GEN1
<?xml version='1.0' ?><rss version="2.0" xmlns:dc="http://purl.org/dc/elements/1.1/">
GEN1;

# Initialize variables
$media = '';
$items = '';

if ($style == 'genresmenu')  {
	$media = '
	<mediaDisplay name="photoView" showHeader="no" rowCount="6" columnCount="4" columnPerPage="4" drawItemText="no" showDefaultInfo="no" itemOffsetXPC="5" itemOffsetYPC="28" sliding="yes" itemBorderColor="0:0:0" itemHeightPC="10" itemWidthPC="21" itemBackgroundColor="0:0:0" idleImageXPC="90" idleImageYPC="5" idleImageWidthPC="5" idleImageHeightPC="6" backgroundColor="0:0:0" bottomYPC="100" sideTopHeightPC="0" mainPartColor="-1:-1:-1" sideColorBottom="-1:-1:-1" sideColorTop="-1:-1:-1">
	<image redraw="no" offsetXPC="0" offsetYPC="4" widthPC="100" heightPC="20">/home/scripts/SIRadio/layout/header.jpg</image>
	
	<itemDisplay>
<image redraw="yes" offsetXPC="0" offsetYPC="0" widthPC="100" heightPC="100" >
<script>
	if ( getFocusItemIndex() == getItemInfo(-1, "nr") )
		"/home/scripts/SIRadio/layout/shoutcast_list_focus.png";
	else
		"/home/scripts/SIRadio/layout/shoutcast_list_unfocus.png";
</script>
</image>

<text redraw="no" offsetXPC="5" offsetYPC="0" widthPC="95" heightPC="100" fontSize="14" foregroundColor="255:255:255">
<script>
	getItemInfo(-1, "title");
</script>
</text>
	</itemDisplay>
	';
}


elseif ($style == 'favoritesmenu')	{
	$nr = 0;
	$media = '
<mediaDisplay name="onePartView" showHeader="no" rowCount="5" columnCount="1" columnPerPage="1" drawItemText="no" showDefaultInfo="no" itemXPC="10" itemYPC="18" sliding="yes" itemPerPage="7" itemGapYPC="2" itemBorderColor="64:64:255" itemHeightPC="10.5" itemWidthPC="80" itemBackgroundColor="0:0:0" idleImageXPC="90" idleImageYPC="5" idleImageWidthPC="5" idleImageHeightPC="8" backgroundColor="0:0:0" sideTopHeightPC="0" sideColorBottom="-1:-1:-1" sideColorTop="-1:-1:-1" sideColorLeft="0:0:0" sideColorRight="0:0:0" mainPartColor="0:0:0" imageFocus=null imageUnFocus=null imageParentFocus=null >
<onUserInput>
<script>
	userInput = currentUserInput();
	Current_Item = getFocusItemIndex();
		
	if (userInput == "display" || userInput == "DISPLAY") {
		f_nr = getItemInfo(Current_Item, "nr");
		url = "http://127.0.0.1:82/SIRadio/index.php?del=" + f_nr;
		doModalRss(url);
		"true";
		redrawDisplay();
	}
</script>
</onUserInput>

<itemDisplay>
<image redraw="yes" offsetXPC="0" offsetYPC="0" widthPC="100" heightPC="100" >
<script>
	if ( getFocusItemIndex() == getItemInfo(-1, "nr") )
		"/home/scripts/SIRadio/layout/MenuItemFO.png";
	else
		"/home/scripts/SIRadio/layout/MenuItemNF.png";
</script>
</image>

<text redraw="no" offsetXPC="1" offsetYPC="0" widthPC="5" heightPC="100" fontSize="13" foregroundColor="255:255:255">
<script>
  numer = getItemInfo(-1, "nr");
  Add(1, numer);
</script>
</text>

<text redraw="no" offsetXPC="5" offsetYPC="0" widthPC="50" heightPC="100" fontSize="13" foregroundColor="255:255:255">
<script>
	getItemInfo(-1, "name");
</script>
</text>

<text redraw="no" offsetXPC="65" offsetYPC="0" widthPC="11" heightPC="100" fontSize="11" foregroundColor="192:192:192">
<script>
	getItemInfo(-1, "type");
</script>
</text>

<text redraw="no" offsetXPC="84" offsetYPC="0" widthPC="9" heightPC="100" fontSize="11" foregroundColor="192:192:192">
<script>
	getItemInfo(-1, "id");
</script>
</text>
</itemDisplay>

<backgroundDisplay>
<image redraw="no" offsetXPC="0" offsetYPC="0" widthPC="100" heightPC="100">/home/scripts/SIRadio/layout/shoutcast_background.jpg</image>
<image redraw="no" offsetXPC="5" offsetYPC="5" widthPC="90" heightPC="92">/home/scripts/SIRadio/layout/shoutcast_list.png</image>

<text redraw="no" offsetXPC="15" offsetYPC="11" widthPC="50" heightPC="5" fontSize="14" backgroundColor="0:0:0" foregroundColor="253:193:0">
Station : [Info] -> Delete
</text>

<text redraw="no" offsetXPC="62" offsetYPC="11" widthPC="10" heightPC="5" fontSize="14" backgroundColor="0:0:0" foregroundColor="253:193:0">
Type
</text>

<text redraw="no" offsetXPC="77.5" offsetYPC="11" widthPC="10" heightPC="5" fontSize="14" backgroundColor="0:0:0" foregroundColor="253:193:0">
ID
</text>
</backgroundDisplay>
	';
	$favfile='/home/scripts/SIRadio/favorites.list'; 
	$fav_all = file($favfile); 
//	$handle = file_get_contents($favfile);
//	$fav_all= explode("\n", $handle);
	
// 	if (($handle == FALSE) || (empty($fav_all)))
	if (empty($fav_all))
		$items = "<item>\n<name>No favorites</name>\n<link>http://127.0.0.1:82/SIRadio/index.php?shoutcastmenu=1</link>\n<type></type>\n<nr>0</nr>\n</item>\n\n";
	else	{
		for ($i=0; $i<count($fav_all); $i++) 	{
			$fav= explode("|", $fav_all[$i]);

			if ($fav[1] == "I")		{
				$url = 'http://127.0.0.1:82/SIRadio/index.php?iceplay=' . $fav[2];
				$typ = 'Icecast';
			}
			else 	{
				$url = 'http://127.0.0.1:82/SIRadio/index.php?play=' . $fav[2];
				$typ = 'Shoutcast';
			}
				
			$items .= "<item>\n<name>" . $fav[0] . "</name>\n<link>" . $url . "</link>\n<type>" . $typ . "</type>\n<nr>" . $nr . "</nr>\n<id>" . $fav[2] . "</id>\n</item>\n\n";
			$nr++;
		}
	}
}


elseif ($style == 'shoutcastmenu')	{
	$media = '
	<mediaDisplay name="photoView" showHeader="no" rowCount="1" columnCount="5" columnPerPage="5" drawItemText="no" showDefaultInfo="no" itemOffsetXPC="2" itemOffsetYPC="78" sliding="yes" itemBorderColor="-1:-1:-1" itemHeightPC="18" itemWidthPC="17.8" itemBackgroundColor="0:0:0" idleImageXPC="90" idleImageYPC="5" idleImageWidthPC="5" idleImageHeightPC="6" backgroundColor="0:0:0" bottomYPC="100" sideTopHeightPC="0" mainPartColor="-1:-1:-1" sideColorBottom="-1:-1:-1" sideColorTop="-1:-1:-1">
	
	<backgroundDisplay>
	<image offsetXPC="0" offsetYPC="0" widthPC="100" heightPC="100">/home/scripts/SIRadio/layout/shoutcast_background.jpg</image>
	</backgroundDisplay>
	';
	
	$items = '
<item>
<title>Search</title>
<link>rss_command://search</link>
<media:thumbnail width="120" height="90">
    <script>
     if (getQueryItemIndex() == 0)
     {
          state=getDrawingItemState();
          if (state == "focus") { "/home/scripts/SIRadio/layout/shoutcast_search_focus.jpg"; }
          else			{ "/home/scripts/SIRadio/layout/shoutcast_search_unfocus.jpg"; }
     }
    </script>
</media:thumbnail>
<search url="http://127.0.0.1:82/SIRadio/index.php?id=%s" />
</item>
	
<item>
<title>Top 100</title>
<link>http://127.0.0.1:82/SIRadio/index.php?id=top100</link>
<media:thumbnail width="120" height="90">
    <script>
     if (getQueryItemIndex() == 1)
     {
          state=getDrawingItemState();
          if (state == "focus") { "/home/scripts/SIRadio/layout/shoutcast_top100_focus.jpg"; }
          else			{ "/home/scripts/SIRadio/layout/shoutcast_top100_unfocus.jpg"; }
     }
    </script>
</media:thumbnail>
</item>
	
<item>
<title>Genres</title>
<link>http://127.0.0.1:82/SIRadio/index.php?genre=primary</link>
<media:thumbnail width="120" height="90">
    <script>
     if (getQueryItemIndex() == 2)
     {
          state=getDrawingItemState();
          if (state == "focus") { "/home/scripts/SIRadio/layout/shoutcast_genres_focus.jpg"; }
          else			{ "/home/scripts/SIRadio/layout/shoutcast_genres_unfocus.jpg"; }
     }
    </script>
</media:thumbnail>
</item>

<item>
<title>Favorites</title>
<link>http://127.0.0.1:82/SIRadio/index.php?favorites=1</link>
<media:thumbnail width="120" height="90">
    <script>
     if (getQueryItemIndex() == 3)
     {
          state=getDrawingItemState();
          if (state == "focus") { "/home/scripts/SIRadio/layout/shoutcast_favorites_focus.jpg"; }
          else			{ "/home/scripts/SIRadio/layout/shoutcast_favorites_unfocus.jpg"; }
     }
    </script>
</media:thumbnail>
</item>

<item>
<title>Random</title>
<link>http://127.0.0.1:82/SIRadio/index.php?id=random</link>
<media:thumbnail width="120" height="90">
    <script>
     if (getQueryItemIndex() == 4)
     {
          state=getDrawingItemState();
          if (state == "focus") { "/home/scripts/SIRadio/layout/shoutcast_random_focus.jpg"; }
          else			{ "/home/scripts/SIRadio/layout/shoutcast_random_unfocus.jpg"; }
     }
    </script>
</media:thumbnail>
</item>
	';
}


else {
	$media = '
	<mediaDisplay name="photoView" showHeader="no" rowCount="1" columnCount="2" columnPerPage="2" drawItemText="no" showDefaultInfo="no" itemOffsetXPC="10" itemOffsetYPC="79" sliding="no" itemBorderColor="0:0:0" itemHeightPC="16" itemWidthPC="40" itemBackgroundColor="-1:-1:-1" idleImageXPC="90" idleImageYPC="5" idleImageWidthPC="5" idleImageHeightPC="6" backgroundColor="-1:-1:-1" bottomYPC="100" sideTopHeightPC="0" mainPartColor="-1:-1:-1" sideColorBottom="-1:-1:-1" sideColorTop="-1:-1:-1">
	
	<itemDisplay>
<image redraw="yes" offsetXPC="0" offsetYPC="0" widthPC="100" heightPC="100" >
<script>
	if ( getFocusItemIndex() == getItemInfo(-1, "nr") )
		"/home/scripts/SIRadio/layout/menu_focus.png";
	else
		"/home/scripts/SIRadio/layout/menu_unfocus.png";
</script>
</image>

<image redraw="yes" offsetXPC="3" offsetYPC="9" widthPC="94" heightPC="82" >
<script>
	getItemInfo(-1, "media");
</script>
</image>
	</itemDisplay>
	
	<backgroundDisplay>
	<image offsetXPC="0" offsetYPC="0" widthPC="100" heightPC="100">/home/scripts/SIRadio/layout/main_background.jpg</image>
	</backgroundDisplay>
		
	';
	
	$items = '
<item>
<title>Shoutcast</title>
<link>http://127.0.0.1:82/SIRadio/index.php?shoutmenu=1</link>
<media>/home/scripts/SIRadio/layout/menu_shoutcast.jpg</media>
<nr>0</nr>
</item>
	
<item>
<title>Icecast</title>
<link>rss_command://search</link>
<media>/home/scripts/SIRadio/layout/menu_icecast.jpg</media>
<nr>1</nr>
<search url="http://127.0.0.1:82/SIRadio/index.php?icesearch=%s" />
</item>
	';
}


echo $media;

echo '
<idleImage>/home/scripts/SIRadio/layout/loading_0.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_1.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_2.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_3.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_4.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_5.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_6.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_7.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_8.png</idleImage>
</mediaDisplay>

<channel>
';

if (!empty($items))
  echo $items;
}



function Footer() {
echo <<<FOOT

</channel>
</rss>
FOOT;
}


function Play($total, $convert, $shoutcast) {
	# Initialize variables
	$rckeys = array("one", "two", "three", "four", "five", "six", "seven", "eight", "nine");

	if ($total > 9)		$total = 9;	
			
	echo '<?xml version="1.0"?>
<rss version="2.0" xmlns:media="http://purl.org/dc/elements/1.1/" xmlns:dc="http://purl.org/dc/elements/1.1/">

<onEnter>
	setRefreshTime(10);
	startPlay = 1;
</onEnter>
';

if (!empty($convert))
{

	if ($shoutcast == TRUE)
		echo '
<onRefresh> 
 	vidProgress = getPlaybackStatus();
	bufProgress = getCachedStreamDataSize(0, 262144);
	playStatus = getStringArrayAt(vidProgress, 3);	

	if (startPlay == 1)
 	{
 		setRefreshTime(1000);
 		startPlay = 0;		
		content = "' .  $convert[0] . '";
		playItemURL(content, 0, "mediaDisplay", "previewWindow");
		updatePlaybackProgress(bufProgress, "mediaDisplay", "progressBar");
	}
	
	if (playStatus == 2) 
	{
		setRefreshTime(20000);
		xmlurl = "http://playon.unixstorm.org/SIRadio/get.php?info=' .  $convert[0] . '";
		xml = loadXMLFile(xmlurl);
		if (xml != null)
		{
			nowPlaying = getXMLText("stream", "now");
			updatePlaybackProgress(bufProgress, "mediaDisplay", "progressBar");
		}
	}
</onRefresh> 
';
	
	else
		echo '
<onRefresh> 
	if (startPlay == 1)
 	{
 		startPlay = 0;		
		playItemURL("' . $convert[0] . '", 5);
 		setRefreshTime(-1);
	}
</onRefresh> 
';
}

echo '
<onExit> 
	playItemURL(-1, 1);
	setRefreshTime(-1);
</onExit>

<mediaDisplay name="onePartView" drawItemText="no" slidingItemText="no" showHeader="no" showDefaultInfo="no" backgroundColor="0:0:0" sliding="no" idleImageXPC="90" idleImageYPC="3" idleImageWidthPC="5" idleImageHeightPC="5">

<idleImage>/home/scripts/SIRadio/layout/loading_0.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_1.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_2.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_3.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_4.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_5.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_6.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_7.png</idleImage>
<idleImage>/home/scripts/SIRadio/layout/loading_8.png</idleImage>
';


	if ($shoutcast == TRUE)
		echo '
<previewWindow windowColor="0:0:0" offsetXPC="2" offsetYPC="2" widthPC="1" heightPC="1"> </previewWindow> 
	
<progressBar backgroundColor="-1:-1:-1" offsetXPC="0" offsetYPC="0" widthPC="100" heightPC="10">

<text offsetXPC="5" offsetYPC="30" widthPC="70" heightPC="70" fontSize="12" backgroundColor="-1:-1:-1" foregroundColor="255:255:255"> 
	<script>"Now playing: " + nowPlaying;</script> 
</text>
	
<text redraw="no" offsetXPC="80" offsetYPC="30" widthPC="10" heightPC="70" fontSize="12" backgroundColor="-1:-1:-1" foregroundColor="255:255:255">
Streams: ' . $total . '
</text>

<destructor offsetXPC="0" offsetYPC="0" widthPC="100" heightPC="100" color="-1:-1:-1"> </destructor> 
</progressBar>';

	else
		echo '
		<text redraw="no" offsetXPC="80" offsetYPC="3" widthPC="10" heightPC="8" fontSize="12" backgroundColor="-1:-1:-1" foregroundColor="255:255:255">
Streams: ' . $total . '
</text>';


echo '
<backgroundDisplay>
<image offsetXPC=0 offsetYPC=0 widthPC=100 heightPC=100>/home/scripts/SIRadio/' . RandomFile('backgrounds/','jpg|png|bmp') . '</image>
</backgroundDisplay>

<onUserInput>
<script>
    userInput = currentUserInput();
';
 
	# Get actual streams
	for ($i=0; $i<count($convert); $i++) 
	{
		if ($i < 9)
		{
			// Create userInput items
			echo '

    if ( userInput == "' . $rckeys[$i] . '" ) {
		playItemURL(-1, 1);
		playItemURL("' . $convert[$i] . '", 5);
		redrawDisplay();
    }
';
		}
	}
  
echo <<<PLAYFOOT

</script>
</onUserInput>

</mediaDisplay>
	    	
<channel>
PLAYFOOT;
}



function IcecastList($search) {
	# Initialize variables
	$nr = 0;
	
	# Get all data
	$page = file_get_contents('http://dir.xiph.org/search?search=' . urlencode($search));
	
	# Find paragraphs
	preg_match_all( "/\<tr class=\"row(.*?)\<\/tr\>/s",  $page, $bookblocks );
  
	# Process radio stations

	if (!empty($bookblocks))	{
	foreach( $bookblocks[1] as $block ) 
	{
		preg_match( "/\/stream\/website\'\);\"\>(.*?)\<\/a\>/", $block, $title );
		preg_match( "/\"listeners\"\>\[(.*?)\&nbsp\;listeners/", $block, $listeners );
		preg_match( "/On Air:\<\/strong\> (.*?)\<\/p\>/", $block, $now );
		preg_match( "/f\=\"\/listen\/(.*?)\/listen.m3u\"/", $block, $stream );		
	
		echo "<item>\n<name>" . htmlspecialchars($title[1], ENT_QUOTES) . "</name>\n<link>http://127.0.0.1:82/SIRadio/index.php?iceplay=" . $stream[1] . "</link>\n<nr>" . $nr . "</nr>\n<id>" . $stream[1] . "</id>\n<bitrate>N.A.</bitrate>\n<now>" . htmlspecialchars($now[1], ENT_QUOTES) . "</now>\n<listeners>" . $listeners[1] . "</listeners>\n</item>\n\n";
		
		$nr++;
	}
	}
	
	else	{
		echo "<item>\n<name>No results</name>\n<link>http://127.0.0.1:82/SIRadio/index.php</link>\n<nr>0</nr>\n<id></id>\n<bitrate></bitrate>\n<now></now>\n<listeners></listeners>\n</item>\n\n";
	}	
	
}



function ShoutcastList($key, $top) {
	# Initialize variables
	$nr = 0;
	$genre = substr($top, 0, 6);
	
	# Connection to API
	if ($top == 'top100')	{
		StationsList(TRUE, 'S');
		$xml = simplexml_load_file("http://api.shoutcast.com/legacy/Top500?limit=100&k=" . $key);
		$go = $xml->station;
	}
	
	elseif ($top == 'random')	{
		StationsList(FALSE, 'S');
		$xml = simplexml_load_file("http://api.shoutcast.com/station/randomstations?limit=10&f=xml&k=" . $key);
		$go = $xml->data->stationlist->station;
	}
	
	elseif ($genre == 'genre_') {
		StationsList(FALSE, 'S');
		$xml = simplexml_load_file("http://api.shoutcast.com/station/advancedsearch?limit=10&f=xml&k=" . $key . "&genre_id=" . substr($top, 6));
		$go = $xml->data->stationlist->station;
	}
	
	else	{
		StationsList(FALSE, 'S');
		$xml = simplexml_load_file("http://api.shoutcast.com/legacy/stationsearch?limit=10&k=" . $key . "&search=" . urlencode($top));
		$go = $xml->station;
	}
	
	if ($xml === FALSE) die('Wrong XML');
	
	if (!empty($go))	{
	
		# Get all data
		foreach ($go as $station) 
		{
			$attr = $station->attributes();
			$titletemp = str_replace(" - a SHOUTcast.com member station", "", $attr['name']);
			$title = htmlspecialchars($titletemp, ENT_QUOTES);
		
			echo "<item>\n<name>" . $title . "</name>\n<link>http://127.0.0.1:82/SIRadio/index.php?play=" . $attr['id'] . "</link>\n<nr>" . $nr . "</nr>\n<id>" . $attr['id'] . "</id>\n<bitrate>" . $attr['br'] . " kbps</bitrate>\n<now>" . htmlspecialchars($attr['ct'], ENT_QUOTES) . "</now>\n<listeners>" . $attr['lc'] . "</listeners>\n</item>\n\n";

			$nr++;
		}
	}
	else	{
		echo "<item>\n<name>No results</name>\n<link>http://127.0.0.1:82/SIRadio/index.php</link>\n<nr>0</nr>\n<id></id>\n<bitrate></bitrate>\n<now></now>\n<listeners></listeners>\n</item>\n\n";
	}
}



function GenresGet($key, $genreid) {
	# Initialize variables
	$nr = 0;
	
	# Connection to API
	if ($genreid == 'primary')	{
		$xml = simplexml_load_file("http://api.shoutcast.com/genre/primary?f=xml&k=" . $key);
		$go = $xml->data->genrelist->genre;
	}
	
	else {
		$xml = simplexml_load_file("http://api.shoutcast.com/genre/secondary?f=xml&k=" . $key . "&parentid=" . $genreid);
		$go = $xml->data->genrelist->genre;
	}
		
	if ($xml === FALSE) die('Wrong XML');
	
	
	# Get all data
	foreach ($go as $genre) 
	{
		$attr = $genre->attributes();
		$title = htmlspecialchars($attr['name'], ENT_QUOTES);
		
		if ($attr['haschildren'] == "true")	
			echo "<item>\n<title>" . $title . "</title>\n<link>http://127.0.0.1:82/SIRadio/index.php?genre=" . $attr['id'] . "</link>\n<nr>" . $nr . "</nr>\n</item>\n\n";
		else
			echo "<item>\n<title>" . $title . "</title>\n<link>http://127.0.0.1:82/SIRadio/index.php?id=genre_" . $attr['id'] . "</link>\n<nr>" . $nr . "</nr>\n</item>\n\n";
		$nr++;
	}
}



function IcecastPlay($ice) {
	# Initialize variables
	$total = 0;
	
	# Get streams
	$handle = file_get_contents('http://dir.xiph.org/listen/' . $ice . '/listen.m3u');
	$convert = explode("\n", $handle);

	for ($i=0; $i<count($convert); $i++) 
		if (!empty($convert[$i]))
		{
			$total++;
			$links[] = trim($convert[$i]);
		}
			
	Play($total, $links, FALSE);
}
	

	
function ShoutcastPlay($key, $play) {
	# Initialize variables
	$total = 0;

	# Get streams
	$handle = file_get_contents('http://yp.shoutcast.com/sbin/tunein-station.pls?k=' . $key . '&id=' . $play);
	$convert = explode("\n", $handle);
	
 	if (strpos($convert[1], 'numberofentries') !== FALSE)
		$total = substr($convert[1], 16);
		
	for ($i=0; $i<count($convert); $i++) 	
		if (strpos($convert[$i], 'File') !== FALSE)
			$links[] = substr($convert[$i], 6);

	Play($total, $links, TRUE);
}


# Main part of program
if (isset($_GET['id'])) 
{
	ShoutcastList($key, $_GET['id']);
	Footer();
}

elseif (isset($_GET['play']))
{
	ShoutcastPlay($key, $_GET['play']);
	Footer();
}

elseif (isset($_GET['iceplay']))
{
	IcecastPlay($_GET['iceplay']);
	Footer();
}

elseif (isset($_GET['icesearch']))
{
	StationsList(FALSE, 'I');
	IcecastList($_GET['icesearch']);
	Footer();
}

elseif (isset($_GET['genre']))
{
	GenresList('genresmenu');
	GenresGet($key, $_GET['genre']);
	Footer();
}

elseif (isset($_GET['shoutmenu']))
{
	GenresList('shoutcastmenu');
	Footer();
}

elseif (isset($_GET['favorites']))
{
	GenresList('favoritesmenu');
	Footer();
}

elseif (isset($_GET['add']))
{
	$newel = $_GET['add'];
	$fh = fopen($favfile, "a+"); 
	fwrite($fh, $newel."\r\n");
	fclose($fh);

	GenresList('favoritesmenu');
	Footer();
}

elseif (isset($_GET['del']))
{
	$news = file($favfile);
	$selLine = $_GET['del'];
	$cnt = 0; 
	foreach ($news as $key => $line) { 
	if ($key!= $selLine) { $result[] = $line; } 
	$cnt+1; 
	} 
	if ($key!= 0) { 
	$fh = fopen($favfile, "w"); 
	foreach ($result as $nyhet) { 
	fwrite($fh, $nyhet); 
	} 
	fclose($fh); 
	} 
	elseif ($key == 0) { 
	$fh = fopen($favfile, "w"); 
	fwrite($fh, ""); 
	fclose($fh); 
	} 
	
	GenresList('favoritesmenu');
	Footer();
}

# Generate menu
else
{
	GenresList('mainmenu');
	Footer();
}

?>