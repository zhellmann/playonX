Realtek RTD1073

This product contains Free Software which is licensed under the GNU General Public License.
After you purchase this product, you may download, modify or distribute the source code of the GPL/LGPL software that is used in this product.

Please be noted that we cannot provide guarantee with the source code, and there is also no technical support for the source code from us.

Applicable to the following AC Ryan model.
-- AC Ryan Playon!HD ACR-PV73100
-- AC Ryan Playon!HD Mini ACR-PV73200